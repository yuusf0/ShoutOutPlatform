import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // ShoutOut brand palette
        lime: {
          DEFAULT: "#C8FF00",
          dark: "#A8D900",
          muted: "#C8FF0020",
        },
        noise: {
          black: "#080808",
          dark: "#0D0D0D",
          card: "#111111",
          border: "#1A1A1A",
          muted: "#333333",
          text: "#888888",
          light: "#CCCCCC",
          white: "#F5F5F5",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "Impact", "Arial Black", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      fontSize: {
        "10xl": ["10rem", { lineHeight: "0.85" }],
        "11xl": ["12rem", { lineHeight: "0.85" }],
        "12xl": ["14rem", { lineHeight: "0.85" }],
      },
      letterSpacing: {
        "ultrawide": "0.3em",
        "brutal": "-0.04em",
      },
      animation: {
        "glitch": "glitch 0.3s infinite",
        "ticker": "ticker 20s linear infinite",
        "pulse-lime": "pulse-lime 2s ease-in-out infinite",
        "fadeUp": "fadeUp 0.8s ease forwards",
        "scanline": "scanline 8s linear infinite",
      },
      keyframes: {
        glitch: {
          "0%, 100%": { transform: "translate(0)" },
          "20%": { transform: "translate(-2px, 2px)" },
          "40%": { transform: "translate(2px, -2px)" },
          "60%": { transform: "translate(-1px, 1px)" },
          "80%": { transform: "translate(1px, -1px)" },
        },
        ticker: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        "pulse-lime": {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(200, 255, 0, 0.4)" },
          "50%": { boxShadow: "0 0 20px 8px rgba(200, 255, 0, 0.15)" },
        },
        fadeUp: {
          from: { opacity: "0", transform: "translateY(30px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        scanline: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100vh)" },
        },
      },
      backgroundImage: {
        "grid-noise": "linear-gradient(rgba(200,255,0,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(200,255,0,0.03) 1px, transparent 1px)",
        "noise-gradient": "linear-gradient(180deg, #080808 0%, #0D0D0D 100%)",
      },
      backgroundSize: {
        "grid": "40px 40px",
      },
    },
  },
  plugins: [],
};

export default config;
