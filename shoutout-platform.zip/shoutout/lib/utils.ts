import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    minimumFractionDigits: 0,
  }).format(price);
}

export function formatPriceUSD(price: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
  }).format(price);
}

export function getTimeUntil(date: Date): {
  days: number; hours: number; minutes: number; seconds: number;
} {
  const now = new Date().getTime();
  const target = new Date(date).getTime();
  const diff = Math.max(0, target - now);

  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
    minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
    seconds: Math.floor((diff % (1000 * 60)) / 1000),
  };
}

export const RARITY_CONFIG = {
  COMMON: { label: "STANDARD", class: "rarity-common" },
  RARE: { label: "LIMITED", class: "rarity-rare" },
  EXCLUSIVE: { label: "EXCLUSIVE", class: "rarity-exclusive" },
  ONE_OF_ONE: { label: "1 OF 1", class: "rarity-one-of-one" },
};

// Mock data for demo
export const MOCK_PRODUCTS = [
  {
    id: "1",
    name: "LOGO TEE — BLACK",
    slug: "logo-tee-black",
    price: 1200,
    comparePrice: null,
    images: ["/api/placeholder/600/750"],
    category: "TEES",
    rarity: "RARE",
    isLimited: true,
    description: "Oversized heavyweight cotton tee. Graffiti logotype screen print front & back. 100% cotton, 280gsm.",
    dropId: "drop-001",
  },
  {
    id: "2",
    name: "LOGO TEE — WHITE",
    slug: "logo-tee-white",
    price: 1200,
    comparePrice: null,
    images: ["/api/placeholder/600/750"],
    category: "TEES",
    rarity: "RARE",
    isLimited: true,
    description: "Oversized heavyweight cotton tee. Graffiti logotype screen print front & back. 100% cotton, 280gsm.",
    dropId: "drop-001",
  },
  {
    id: "3",
    name: "NOISE HOODIE",
    slug: "noise-hoodie",
    price: 2200,
    comparePrice: 2800,
    images: ["/api/placeholder/600/750"],
    category: "HOODIES",
    rarity: "EXCLUSIVE",
    isLimited: true,
    description: "Premium heavyweight fleece. Embroidered logo. Dropped shoulders, tunnel drawcords.",
    dropId: "drop-001",
  },
  {
    id: "4",
    name: "SHOUT CAP",
    slug: "shout-cap",
    price: 800,
    comparePrice: null,
    images: ["/api/placeholder/600/750"],
    category: "ACCESSORIES",
    rarity: "COMMON",
    isLimited: false,
    description: "6-panel structured cap. Embroidered wordmark. Adjustable snapback.",
    dropId: null,
  },
];

export const MOCK_DROPS = [
  {
    id: "drop-001",
    name: "DROP 001 — THE FIRST NOISE",
    slug: "drop-001",
    description: "The beginning. 10 pieces. No restock.",
    dropDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3),
    coverImage: null,
    isActive: true,
  }
];
