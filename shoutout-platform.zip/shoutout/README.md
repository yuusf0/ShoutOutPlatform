# ShoutOut™ — Premium Streetwear E-Commerce Platform

> "Identity first. Commerce second."

A production-ready, culture-first streetwear platform built on Next.js 15 — inspired by Supreme exclusivity, Corteiz energy, and adidaschile20.com cinematic presentation.

---

## ⚡ Tech Stack

| Layer      | Tech                              |
|------------|-----------------------------------|
| Frontend   | Next.js 15 (App Router), TypeScript |
| Styling    | TailwindCSS (brand tokens)        |
| Animation  | GSAP, Framer Motion               |
| State      | Zustand (cart + wishlist)         |
| Database   | PostgreSQL + Prisma ORM           |
| Auth       | Clerk / Auth.js                   |
| Payments   | Stripe                            |
| Storage    | Cloudinary                        |
| Deploy     | Vercel                            |

---

## 🗂 Project Structure

```
shoutout/
├── app/                     # Next.js App Router pages
│   ├── page.tsx             # Landing page (Hero + Drops + Lookbook + Community)
│   ├── shop/                # Product catalog + [slug] detail page
│   ├── drops/               # Drop listing page
│   ├── lookbook/            # Editorial lookbook
│   ├── archive/             # Past drops archive
│   ├── culture/             # Brand story page
│   ├── checkout/            # Multi-step checkout (Info → Shipping → Payment)
│   ├── account/             # User dashboard (Orders, Wishlist, Addresses)
│   ├── sign-in/             # Auth — Sign In
│   ├── sign-up/             # Auth — Sign Up
│   ├── admin/               # ShoutOut OS — Admin Panel
│   │   ├── page.tsx         # Dashboard (stats + charts + recent orders)
│   │   ├── products/        # Product CRUD + variant management
│   │   ├── drops/           # Drop scheduling + management
│   │   ├── orders/          # Order tracking + status + refunds
│   │   ├── community/       # Early access, newsletter, Discord
│   │   ├── analytics/       # Revenue, category, top products charts
│   │   ├── content/         # Hero banners, countdown, homepage modules
│   │   └── settings/        # Store, shipping, payment config
│   └── api/                 # API Route Handlers
│       ├── newsletter/      # Newsletter subscribe
│       ├── early-access/    # Whitelist registration
│       ├── products/        # Products endpoint
│       ├── orders/          # Orders CRUD
│       └── checkout/        # Stripe session creation
│
├── components/
│   ├── layout/              # Navbar (sticky + mobile menu + ticker), Footer
│   ├── cart/                # Slide-over cart panel
│   ├── home/                # Hero, MarqueeTicker, DropSection, Campaign, Lookbook, Community
│   └── ui/                  # CustomCursor, NoiseOverlay
│
├── store/
│   ├── cart.ts              # Zustand cart store (persisted)
│   └── wishlist.ts          # Zustand wishlist store (persisted)
│
├── lib/
│   └── utils.ts             # cn(), formatPrice(), RARITY_CONFIG, mock data
│
└── prisma/
    └── schema.prisma        # Full DB schema (Products, Variants, Drops, Orders, etc.)
```

---

## 🚀 Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment variables
```bash
cp .env.local.example .env.local
```

Fill in:
```env
DATABASE_URL=postgresql://...
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_live_...
CLERK_SECRET_KEY=sk_live_...
STRIPE_SECRET_KEY=sk_live_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=...
```

### 3. Push database schema
```bash
npx prisma db push
npx prisma generate
```

### 4. Run development server
```bash
npm run dev
```

---

## 🎨 Design System

### Brand Colors
| Token        | Hex       | Usage                  |
|-------------|-----------|------------------------|
| `lime`      | `#C8FF00` | Primary accent, CTAs   |
| `noise-black` | `#080808` | Background             |
| `noise-dark` | `#0D0D0D` | Cards, sections        |
| `noise-border` | `#1A1A1A` | Borders, dividers     |
| `noise-white` | `#F5F5F5` | Primary text           |
| `noise-text` | `#888888` | Muted / secondary text |

### Typography
- **Display**: Bebas Neue — oversized headings, logos
- **Body**: Space Grotesk — UI text, descriptions
- **Mono**: Space Mono — labels, prices, badges

### Rarity System
| Level       | Badge       | Visual               |
|------------|-------------|----------------------|
| COMMON     | STANDARD    | Dark grey            |
| RARE       | LIMITED     | Green tinted         |
| EXCLUSIVE  | EXCLUSIVE   | Purple tinted        |
| ONE_OF_ONE | 1 OF 1      | Red tinted + border  |

---

## 📦 Pages Overview

| Route              | Description                                          |
|--------------------|------------------------------------------------------|
| `/`                | Hero with word-by-word intro animation, drop reveal, lookbook, community |
| `/shop`            | Filterable product grid with quick-add               |
| `/shop/[slug]`     | Product detail: gallery, size picker, stock, wishlist |
| `/drops`           | Upcoming drop with live countdown                    |
| `/lookbook`        | Editorial hover-expand looks                         |
| `/archive`         | Past drops (grows over time)                         |
| `/culture`         | Brand story / manifesto                              |
| `/checkout`        | 3-step: Information → Shipping → Payment             |
| `/account`         | Orders, wishlist, addresses, profile                 |
| `/sign-in`         | Premium split-screen sign-in                         |
| `/sign-up`         | Lime-panel sign-up with early access opt-in          |
| `/admin`           | ShoutOut OS dashboard                                |
| `/admin/products`  | Product CRUD with rarity + variant management        |
| `/admin/drops`     | Drop scheduling and live management                  |
| `/admin/orders`    | Order tracking, status updates, refunds              |
| `/admin/community` | Whitelist, newsletter, Discord management            |
| `/admin/analytics` | Revenue charts, category breakdown, top products     |
| `/admin/content`   | CMS: hero banners, countdown, homepage modules       |
| `/admin/settings`  | Store config: shipping, payments, domain             |

---

## 🔌 Integrations to Connect

### Clerk Auth
1. Create project at clerk.com
2. Copy keys to `.env.local`
3. Wrap layout with `<ClerkProvider>`
4. Replace auth pages with `<SignIn />` / `<SignUp />` components

### Stripe Payments
1. Create product + prices in Stripe dashboard
2. Set `STRIPE_SECRET_KEY` and webhook secret
3. Replace mock checkout with `stripe.checkout.sessions.create()`

### Cloudinary
1. Create account at cloudinary.com
2. Set cloud name + keys
3. Use `<CldImage>` from `next-cloudinary` for product images

### Supabase (Database)
1. Create project, get connection string
2. Set `DATABASE_URL` in `.env.local`
3. Run `npx prisma db push`

---

## 🌐 Deploy to Vercel

```bash
vercel --prod
```

Set all env vars in Vercel dashboard → Project → Settings → Environment Variables.

---

## ✅ Production Checklist

- [ ] Connect Clerk for real authentication
- [ ] Connect Stripe for live payments
- [ ] Set up Cloudinary for product image uploads
- [ ] Configure Supabase/PostgreSQL database
- [ ] Add real product images
- [ ] Set up Stripe webhook → `/api/webhook`
- [ ] Configure custom domain
- [ ] Enable Vercel Analytics
- [ ] Add Discord bot for community management
- [ ] Set up email (Resend/Postmark) for order confirmations

---

## 🔊 THE NOISE IS COMING

Built for ShoutOut™ — Bursa, Turkey. 2026.
