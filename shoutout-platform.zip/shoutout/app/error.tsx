"use client";
import { useEffect } from "react";
import Link from "next/link";

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  useEffect(() => { console.error(error); }, [error]);
  return (
    <div className="min-h-screen bg-noise-black flex flex-col items-center justify-center text-center px-6">
      <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">SOMETHING BROKE</p>
      <h1 className="font-display text-7xl text-noise-white mb-6">ERROR</h1>
      <p className="font-body text-noise-text mb-8 max-w-xs">An unexpected error occurred. The noise will continue.</p>
      <div className="flex gap-4">
        <button onClick={reset} className="btn-lime px-6 py-3 text-base">TRY AGAIN</button>
        <Link href="/" className="btn-outline px-6 py-3 text-base">HOME</Link>
      </div>
    </div>
  );
}
