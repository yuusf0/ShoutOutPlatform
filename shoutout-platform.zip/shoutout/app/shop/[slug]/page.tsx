"use client";
import { useState } from "react";
import { use } from "react";
import Link from "next/link";
import { Heart, ShoppingBag, Ruler, ChevronDown, ChevronRight, Zap, Star } from "lucide-react";
import { MOCK_PRODUCTS, formatPrice, RARITY_CONFIG } from "@/lib/utils";
import { useCartStore } from "@/store/cart";
import { useWishlistStore } from "@/store/wishlist";
import toast from "react-hot-toast";

const SIZES = ["XS", "S", "M", "L", "XL", "XXL"];
const STOCK = { XS: 2, S: 3, M: 5, L: 4, XL: 2, XXL: 1 };

export default function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const product = MOCK_PRODUCTS.find((p) => p.slug === slug) || MOCK_PRODUCTS[0];
  const rarity = RARITY_CONFIG[product.rarity as keyof typeof RARITY_CONFIG];

  const [selectedSize, setSelectedSize] = useState("");
  const [activeImage, setActiveImage] = useState(0);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(true);

  const { addItem, openCart } = useCartStore();
  const { toggle, has } = useWishlistStore();
  const isWished = has(product.id);

  const handleAddToCart = () => {
    if (!selectedSize) {
      toast.error("Select a size first");
      return;
    }
    addItem({
      id: `${product.id}-${selectedSize}`,
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: selectedSize,
      slug: product.slug,
    });
    toast.success(`${product.name} — ${selectedSize} added`);
    openCart();
  };

  const stockForSize = (size: string) => STOCK[size as keyof typeof STOCK] || 0;
  const isLowStock = (size: string) => stockForSize(size) <= 2;

  return (
    <div className="min-h-screen pt-20">
      {/* Breadcrumb */}
      <div className="px-6 lg:px-12 py-4 border-b border-noise-border">
        <div className="max-w-7xl mx-auto flex items-center gap-2 font-mono text-xs text-noise-text">
          <Link href="/" className="hover:text-lime transition-colors">HOME</Link>
          <ChevronRight size={12} />
          <Link href="/shop" className="hover:text-lime transition-colors">SHOP</Link>
          <ChevronRight size={12} />
          <span className="text-noise-white">{product.name}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Image gallery */}
          <div className="space-y-3">
            {/* Main image */}
            <div className="relative aspect-[4/5] bg-noise-card border border-noise-border overflow-hidden group">
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-noise-card to-noise-dark">
                <span className="font-display text-[10rem] text-noise-border/30 group-hover:scale-105 transition-transform duration-700">SO</span>
              </div>

              {/* Rarity badge */}
              <div className="absolute top-4 left-4">
                <span className={`text-xs font-mono px-3 py-1 tracking-widest ${rarity?.class}`}>
                  {rarity?.label}
                </span>
              </div>

              {/* Limited badge */}
              {product.isLimited && (
                <div className="absolute top-4 right-4">
                  <span className="bg-lime text-noise-black text-[10px] font-mono font-bold px-3 py-1 tracking-widest">
                    LIMITED
                  </span>
                </div>
              )}

              {/* Wishlist */}
              <button
                onClick={() => { toggle(product.id); toast.success(isWished ? "Removed from wishlist" : "Added to wishlist"); }}
                className="absolute bottom-4 right-4 w-10 h-10 bg-noise-black/80 border border-noise-border flex items-center justify-center hover:border-lime transition-all"
              >
                <Heart size={16} className={isWished ? "text-lime fill-lime" : "text-noise-text"} />
              </button>
            </div>

            {/* Thumbnails */}
            <div className="grid grid-cols-4 gap-2">
              {[0, 1, 2, 3].map((i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={`aspect-square bg-noise-card border flex items-center justify-center transition-all ${
                    activeImage === i ? "border-lime" : "border-noise-border hover:border-noise-muted"
                  }`}
                >
                  <span className="font-display text-2xl text-noise-border/40">SO</span>
                </button>
              ))}
            </div>
          </div>

          {/* Product info */}
          <div className="flex flex-col gap-6">
            {/* Drop badge */}
            {product.dropId && (
              <Link
                href={`/drops/${product.dropId}`}
                className="inline-flex items-center gap-2 font-mono text-xs text-lime tracking-ultrawide hover:text-noise-white transition-colors w-fit"
              >
                <Zap size={10} /> DROP 001 — THE FIRST NOISE
              </Link>
            )}

            {/* Name + price */}
            <div>
              <h1 className="font-display text-[clamp(2.5rem,5vw,4rem)] text-noise-white leading-none mb-3">
                {product.name}
              </h1>
              <div className="flex items-center gap-4">
                <span className="font-mono text-2xl text-lime">{formatPrice(product.price)}</span>
                {product.comparePrice && (
                  <span className="font-mono text-base text-noise-muted line-through">{formatPrice(product.comparePrice)}</span>
                )}
              </div>
            </div>

            {/* Stock tracker */}
            <div className="flex items-center gap-3 p-3 border border-noise-border bg-noise-card/50">
              <div className="w-2 h-2 rounded-full bg-lime animate-pulse" />
              <span className="font-mono text-xs text-noise-text">IN STOCK — SHIPS IN 2-4 DAYS</span>
              <span className="font-mono text-xs text-lime ml-auto">17 REMAINING</span>
            </div>

            {/* Size selection */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="font-mono text-xs text-noise-text tracking-ultrawide">SELECT SIZE</span>
                <button
                  onClick={() => setSizeGuideOpen(!sizeGuideOpen)}
                  className="font-mono text-xs text-lime flex items-center gap-1 hover:text-noise-white transition-colors"
                >
                  <Ruler size={11} /> SIZE GUIDE
                </button>
              </div>
              <div className="grid grid-cols-6 gap-2">
                {SIZES.map((size) => {
                  const stock = stockForSize(size);
                  const lowStock = isLowStock(size);
                  return (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      disabled={stock === 0}
                      className={`relative py-3 font-mono text-sm border transition-all ${
                        selectedSize === size
                          ? "border-lime text-lime bg-lime/5"
                          : stock === 0
                          ? "border-noise-border text-noise-border cursor-not-allowed opacity-40"
                          : "border-noise-border text-noise-text hover:border-noise-muted"
                      }`}
                    >
                      {size}
                      {lowStock && stock > 0 && (
                        <span className="absolute -top-1 -right-1 w-2 h-2 bg-yellow-500 rounded-full" title="Low stock" />
                      )}
                    </button>
                  );
                })}
              </div>
              {selectedSize && (
                <p className="font-mono text-xs text-noise-text mt-2">
                  {stockForSize(selectedSize)} left in {selectedSize}
                  {isLowStock(selectedSize) && " — LOW STOCK"}
                </p>
              )}
            </div>

            {/* Size guide */}
            {sizeGuideOpen && (
              <div className="border border-lime/20 bg-noise-card p-4">
                <p className="font-mono text-xs text-lime mb-3 tracking-ultrawide">SIZE GUIDE (CM)</p>
                <table className="w-full font-mono text-xs text-noise-text">
                  <thead>
                    <tr className="border-b border-noise-border">
                      {["SIZE", "CHEST", "LENGTH", "SLEEVE"].map((h) => (
                        <th key={h} className="text-left pb-2 text-noise-white">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="space-y-1">
                    {[
                      ["XS", "92", "66", "58"], ["S", "96", "68", "60"],
                      ["M", "100", "70", "62"], ["L", "104", "72", "64"],
                      ["XL", "108", "74", "66"], ["XXL", "112", "76", "68"],
                    ].map(([size, ...vals]) => (
                      <tr key={size} className="border-b border-noise-border/50">
                        <td className="py-1.5 text-noise-white">{size}</td>
                        {vals.map((v, i) => <td key={i} className="py-1.5">{v}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="font-mono text-[10px] text-noise-text mt-3">Oversized fit. Size up for extreme oversized look.</p>
              </div>
            )}

            {/* CTA buttons */}
            <div className="flex gap-3">
              <button
                onClick={handleAddToCart}
                className="btn-lime flex-1 py-4 text-lg flex items-center justify-center gap-2"
              >
                <ShoppingBag size={18} />
                {selectedSize ? `ADD TO BAG — ${selectedSize}` : "SELECT SIZE"}
              </button>
              <button
                onClick={() => { toggle(product.id); toast.success(isWished ? "Removed from wishlist" : "Saved to wishlist"); }}
                className={`w-14 border flex items-center justify-center transition-all ${
                  isWished ? "border-lime text-lime bg-lime/5" : "border-noise-border text-noise-text hover:border-lime hover:text-lime"
                }`}
              >
                <Heart size={18} className={isWished ? "fill-lime" : ""} />
              </button>
            </div>

            {/* Details accordion */}
            <div className="border border-noise-border">
              <button
                onClick={() => setDetailsOpen(!detailsOpen)}
                className="w-full flex items-center justify-between px-4 py-3 font-mono text-xs tracking-ultrawide text-noise-text hover:text-noise-white transition-colors"
              >
                PRODUCT DETAILS <ChevronDown size={14} className={`transition-transform ${detailsOpen ? "rotate-180" : ""}`} />
              </button>
              {detailsOpen && (
                <div className="px-4 pb-4 border-t border-noise-border">
                  <p className="font-body text-sm text-noise-text leading-relaxed mt-3">{product.description}</p>
                  <ul className="mt-4 space-y-1">
                    {["100% cotton, 280gsm heavyweight", "Oversized fit — true to size", "Screen-printed graphics, front & back", "Reinforced neck seam", "Woven label inside collar"].map((item) => (
                      <li key={item} className="font-mono text-xs text-noise-text flex items-center gap-2">
                        <span className="text-lime">—</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Shipping info */}
            <div className="border border-noise-border p-4 space-y-2">
              {[
                { label: "FREE SHIPPING", desc: "On orders over ₺1500" },
                { label: "RETURNS", desc: "14 days for unworn items" },
                { label: "SHIPS FROM", desc: "Bursa, Turkey — 2-4 days domestic" },
              ].map(({ label, desc }) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="font-mono text-xs text-lime">{label}</span>
                  <span className="font-mono text-xs text-noise-text">{desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Complete the fit */}
        <div className="mt-20 pt-12 border-t border-noise-border">
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">COMPLETE THE FIT</p>
          <h3 className="font-display text-4xl text-noise-white mb-8">YOU MIGHT ALSO WANT</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {MOCK_PRODUCTS.filter((p) => p.id !== product.id).slice(0, 4).map((p) => (
              <Link key={p.id} href={`/shop/${p.slug}`} className="product-card group border border-noise-border hover:border-lime/30 transition-all bg-noise-card">
                <div className="aspect-[3/4] overflow-hidden flex items-center justify-center bg-noise-dark">
                  <span className="font-display text-5xl text-noise-border/40 group-hover:text-noise-muted transition-colors">SO</span>
                </div>
                <div className="p-3">
                  <p className="font-display text-sm tracking-wider text-noise-white group-hover:text-lime transition-colors leading-tight">{p.name}</p>
                  <p className="font-mono text-xs text-lime mt-1">{formatPrice(p.price)}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
