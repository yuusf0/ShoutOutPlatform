"use client";
import { useState } from "react";
import Link from "next/link";
import { SlidersHorizontal, X, Zap } from "lucide-react";
import { MOCK_PRODUCTS, formatPrice, RARITY_CONFIG } from "@/lib/utils";
import { useCartStore } from "@/store/cart";
import toast from "react-hot-toast";

const CATEGORIES = ["ALL", "TEES", "HOODIES", "ACCESSORIES"];
const SORT_OPTIONS = ["NEWEST", "PRICE: LOW", "PRICE: HIGH", "LIMITED FIRST"];

export default function ShopPage() {
  const [activeCategory, setActiveCategory] = useState("ALL");
  const [activeSort, setActiveSort] = useState("NEWEST");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const { addItem } = useCartStore();

  const filtered = MOCK_PRODUCTS.filter(
    (p) => activeCategory === "ALL" || p.category === activeCategory
  );

  const sorted = [...filtered].sort((a, b) => {
    if (activeSort === "PRICE: LOW") return a.price - b.price;
    if (activeSort === "PRICE: HIGH") return b.price - a.price;
    if (activeSort === "LIMITED FIRST") return (b.isLimited ? 1 : 0) - (a.isLimited ? 1 : 0);
    return 0;
  });

  return (
    <div className="min-h-screen pt-24">
      {/* Header */}
      <div className="px-6 lg:px-12 py-10 border-b border-noise-border">
        <div className="max-w-7xl mx-auto">
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">ALL PIECES</p>
          <h1 className="font-display text-[clamp(3rem,8vw,6rem)] text-noise-white leading-none">SHOP</h1>
        </div>
      </div>

      {/* Filters bar */}
      <div className="sticky top-16 z-30 bg-noise-black/95 backdrop-blur-sm border-b border-noise-border px-6 lg:px-12 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Categories */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`font-mono text-xs px-4 py-2 border whitespace-nowrap transition-all ${
                  activeCategory === cat
                    ? "border-lime text-lime bg-lime/5"
                    : "border-noise-border text-noise-text hover:border-noise-muted"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Sort + filter */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <select
              value={activeSort}
              onChange={(e) => setActiveSort(e.target.value)}
              className="shoutout-input font-mono text-xs px-3 py-2 bg-noise-black cursor-pointer"
            >
              {SORT_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
            <span className="font-mono text-xs text-noise-text">{sorted.length} PIECES</span>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {sorted.map((product) => {
            const rarity = RARITY_CONFIG[product.rarity as keyof typeof RARITY_CONFIG];
            return (
              <div key={product.id} className="product-card group relative bg-noise-card border border-noise-border hover:border-lime/30 transition-all duration-300">
                <Link href={`/shop/${product.slug}`}>
                  <div className="relative overflow-hidden aspect-[3/4] bg-noise-dark">
                    <div className="product-image w-full h-full transition-transform duration-500 flex items-center justify-center">
                      <span className="font-display text-6xl text-noise-border/50 group-hover:text-noise-muted transition-colors">SO</span>
                    </div>

                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                      {product.isLimited && (
                        <span className="bg-lime text-noise-black text-[9px] font-mono font-bold px-2 py-0.5 tracking-widest">LIMITED</span>
                      )}
                      <span className={`text-[9px] font-mono px-2 py-0.5 tracking-widest ${rarity?.class}`}>
                        {rarity?.label}
                      </span>
                    </div>

                    {/* Quick add */}
                    <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          addItem({ id: product.id + "-M", productId: product.id, name: product.name, price: product.price, image: product.images[0], size: "M", slug: product.slug });
                          toast.success("Added to bag");
                        }}
                        className="btn-lime w-full py-3 text-sm flex items-center justify-center gap-2"
                      >
                        <Zap size={13} /> QUICK ADD
                      </button>
                    </div>
                  </div>
                </Link>

                <div className="p-3">
                  <Link href={`/shop/${product.slug}`}>
                    <p className="font-display text-sm tracking-wider text-noise-white hover:text-lime transition-colors leading-tight mb-0.5">
                      {product.name}
                    </p>
                  </Link>
                  <p className="font-mono text-[10px] text-noise-text">{product.category}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-mono text-sm text-lime">{formatPrice(product.price)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {sorted.length === 0 && (
          <div className="text-center py-20">
            <p className="font-display text-3xl text-noise-border">NOTHING HERE YET</p>
            <p className="font-mono text-sm text-noise-text mt-2">Check back for new drops</p>
          </div>
        )}
      </div>
    </div>
  );
}
