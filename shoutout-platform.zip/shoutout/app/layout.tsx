import type { Metadata, Viewport } from "next";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Cart from "@/components/cart/Cart";
import CustomCursor from "@/components/ui/CustomCursor";
import NoiseOverlay from "@/components/ui/NoiseOverlay";
import { Toaster } from "react-hot-toast";

export const metadata: Metadata = {
  title: "ShoutOut™ — The Noise Is Coming",
  description: "Culture-first underground streetwear. Limited drops. No restock.",
  keywords: ["streetwear", "limited drops", "underground fashion", "ShoutOut"],
  authors: [{ name: "ShoutOut" }],
  openGraph: {
    title: "ShoutOut™ — The Noise Is Coming",
    description: "Culture-first underground streetwear. Limited drops. No restock.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#080808",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Space+Grotesk:wght@300;400;500;600;700&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-noise-black text-noise-white min-h-screen font-body antialiased">
        <NoiseOverlay />
        <CustomCursor />
        <Navbar />
        <Cart />
        <main>{children}</main>
        <Footer />
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: "#111111",
              color: "#F5F5F5",
              border: "1px solid #1A1A1A",
              fontFamily: "Space Grotesk, sans-serif",
              fontSize: "13px",
            },
            success: {
              iconTheme: { primary: "#C8FF00", secondary: "#080808" },
            },
          }}
        />
      </body>
    </html>
  );
}
