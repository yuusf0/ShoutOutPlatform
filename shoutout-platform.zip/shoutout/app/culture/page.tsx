export default function CulturePage() {
  return (
    <div className="min-h-screen pt-20">
      <div className="px-6 lg:px-12 py-12 border-b border-noise-border">
        <div className="max-w-7xl mx-auto">
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-3">THE STORY</p>
          <h1 className="font-display text-[clamp(3.5rem,9vw,7rem)] text-noise-white leading-none">CULTURE</h1>
        </div>
      </div>
      <div className="max-w-4xl mx-auto px-6 lg:px-12 py-20 space-y-16">
        {[
          { num:"01", title:"THE BEGINNING", body:"ShoutOut started as a shout — a refusal to be quiet in a market flooded with replicas and borrowed aesthetics. Born in Bursa, Turkey, in 2026. Underground by design. Premium by execution." },
          { num:"02", title:"THE CULTURE", body:"We are rooted in Turkish street and rap culture. The energy of Kava, the aggression of Attack_un, the silence of Tetha before the drop. That's the ShoutOut frequency." },
          { num:"03", title:"THE PHILOSOPHY", body:"Identity first. Commerce second. We don't make clothes for everyone. We make clothes for those who already understand — and those who are about to." },
          { num:"04", title:"THE FUTURE", body:"Limited drops. No restock. Ever. Each piece is a timestamp. A moment in the culture. Miss it and it's gone. That's the point." },
        ].map(({num,title,body})=>(
          <div key={num} className="grid grid-cols-[auto_1fr] gap-8 items-start border-t border-noise-border pt-12">
            <span className="font-display text-6xl text-lime leading-none">{num}</span>
            <div>
              <h2 className="font-display text-4xl text-noise-white mb-4">{title}</h2>
              <p className="font-body text-noise-text leading-relaxed">{body}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
