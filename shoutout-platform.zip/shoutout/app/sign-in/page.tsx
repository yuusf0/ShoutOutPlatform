"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Eye, EyeOff } from "lucide-react";
import toast from "react-hot-toast";

export default function SignInPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Signed in — welcome back.");
    setTimeout(() => window.location.href = "/account", 800);
  };

  return (
    <div className="min-h-screen bg-noise-black flex">
      {/* Left panel – branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-noise-dark border-r border-noise-border flex-col justify-between p-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-noise bg-grid opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-br from-lime/5 to-transparent" />
        <div className="relative">
          <Link href="/" className="flex items-baseline gap-1">
            <span className="font-display text-3xl text-noise-white">SHOUTOUT</span>
            <span className="text-lime text-sm font-mono">™</span>
          </Link>
        </div>
        <div className="relative">
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">THE CULTURE</p>
          <h2 className="font-display text-7xl text-noise-white leading-none mb-6">
            WELCOME<br/>BACK.
          </h2>
          <p className="font-body text-noise-text text-sm leading-relaxed max-w-xs">
            Sign in to access your orders, wishlist, and early drop access.
          </p>
        </div>
        <p className="relative font-mono text-xs text-noise-border">© 2026 SHOUTOUT™</p>
      </div>

      {/* Right panel – form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center px-6 py-20">
        <div className="w-full max-w-md space-y-8">
          {/* Mobile logo */}
          <div className="lg:hidden">
            <Link href="/" className="flex items-baseline gap-1">
              <span className="font-display text-2xl text-noise-white">SHOUTOUT</span>
              <span className="text-lime text-xs font-mono">™</span>
            </Link>
          </div>

          <div>
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">MEMBER ACCESS</p>
            <h1 className="font-display text-5xl text-noise-white">SIGN IN</h1>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">EMAIL</label>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)} required
                placeholder="your@email.com"
                className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"
              />
            </div>
            <div>
              <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">PASSWORD</label>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"} value={password}
                  onChange={e => setPassword(e.target.value)} required
                  placeholder="••••••••"
                  className="shoutout-input w-full px-4 py-3 pr-12 text-sm font-mono tracking-widest"
                />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-noise-text hover:text-lime transition-colors">
                  {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>
            <div className="flex justify-end">
              <a href="#" className="font-mono text-xs text-noise-text hover:text-lime transition-colors">FORGOT PASSWORD?</a>
            </div>
            <button type="submit" className="btn-lime w-full py-4 text-lg flex items-center justify-center gap-2">
              SIGN IN <ArrowRight size={16}/>
            </button>
          </form>

          <div className="border-t border-noise-border pt-6 flex items-center justify-between">
            <p className="font-mono text-xs text-noise-text">DON'T HAVE AN ACCOUNT?</p>
            <Link href="/sign-up" className="font-mono text-xs text-lime hover:text-noise-white transition-colors flex items-center gap-1">
              CREATE ONE <ArrowRight size={11}/>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
