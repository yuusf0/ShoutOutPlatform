import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json();
    if (!email || !email.includes("@")) {
      return NextResponse.json({ error: "Invalid email" }, { status: 400 });
    }
    // In production: save to DB via Prisma
    return NextResponse.json({ success: true, message: "Subscribed" });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
