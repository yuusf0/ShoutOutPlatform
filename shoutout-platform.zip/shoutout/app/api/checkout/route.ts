import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { items, email, address } = await req.json();
    if (!items?.length) return NextResponse.json({ error: "No items" }, { status: 400 });

    // In production: create Stripe checkout session
    const mockSessionUrl = `/checkout?session=mock_${Date.now()}`;
    return NextResponse.json({ url: mockSessionUrl, sessionId: `cs_mock_${Date.now()}` });
  } catch {
    return NextResponse.json({ error: "Checkout error" }, { status: 500 });
  }
}
