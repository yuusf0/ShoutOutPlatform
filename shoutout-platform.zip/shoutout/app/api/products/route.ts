import { NextRequest, NextResponse } from "next/server";
import { MOCK_PRODUCTS } from "@/lib/utils";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category");
  const dropId   = searchParams.get("dropId");

  let products = MOCK_PRODUCTS;
  if (category && category !== "ALL") products = products.filter(p => p.category === category);
  if (dropId) products = products.filter(p => p.dropId === dropId);

  return NextResponse.json({ products, total: products.length });
}
