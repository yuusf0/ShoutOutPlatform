import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get("userId");
  // In production: query Prisma
  return NextResponse.json({ orders: [], total: 0 });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    return NextResponse.json({ success: true, orderId: `SO-${Date.now()}` });
  } catch {
    return NextResponse.json({ error: "Order failed" }, { status: 500 });
  }
}
