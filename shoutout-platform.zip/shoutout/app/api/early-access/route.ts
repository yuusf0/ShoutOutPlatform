import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { email, dropId } = await req.json();
    if (!email) return NextResponse.json({ error: "Email required" }, { status: 400 });
    return NextResponse.json({ success: true, spotsRemaining: 77 });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
