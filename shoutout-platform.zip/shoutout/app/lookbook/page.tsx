"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

const LOOKS = [
  { id: 1, label: "LOOK 01", title: "THE SIGNAL", desc: "Black Logo Tee + Cargo Pants + Triple White", products: ["logo-tee-black"] },
  { id: 2, label: "LOOK 02", title: "THE MOVE",  desc: "White Logo Tee + Basketball Shorts + Forces", products: ["logo-tee-white"] },
  { id: 3, label: "LOOK 03", title: "THE NOISE", desc: "Noise Hoodie + Track Pants + Boots",          products: ["noise-hoodie"] },
  { id: 4, label: "LOOK 04", title: "THE CAP",   desc: "ShoutOut Cap + Logo Tee + Denim",            products: ["shout-cap"] },
];

export default function LookbookPage() {
  const [active, setActive] = useState<number | null>(null);

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <div className="px-6 lg:px-12 py-12 border-b border-noise-border">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-start lg:items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-3">DROP 001</p>
            <h1 className="font-display text-[clamp(3.5rem,9vw,7rem)] text-noise-white leading-none">LOOKBOOK</h1>
          </div>
          <p className="font-body text-noise-text max-w-xs leading-relaxed text-sm">
            Four looks. One drop. How you wear it defines the culture.
          </p>
        </div>
      </div>

      {/* Full-width look grid */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-12 space-y-4">
        {LOOKS.map((look, idx) => (
          <div
            key={look.id}
            className={`group relative border border-noise-border overflow-hidden cursor-pointer transition-all duration-500 ${
              active === look.id ? "border-lime/40" : "hover:border-noise-muted"
            }`}
            onMouseEnter={() => setActive(look.id)}
            onMouseLeave={() => setActive(null)}
          >
            <div className={`flex flex-col lg:flex-row items-stretch transition-all duration-500 ${
              active === look.id ? "bg-noise-card" : "bg-noise-dark"
            }`}>
              {/* Image */}
              <div className={`relative overflow-hidden flex-shrink-0 transition-all duration-500 ${
                active === look.id ? "lg:w-1/2" : "lg:w-1/3"
              }`}>
                <div className="aspect-[3/2] lg:aspect-auto lg:h-64 bg-noise-dark flex items-center justify-center relative">
                  <div className="absolute inset-0 bg-grid-noise bg-grid opacity-20" />
                  <span className="font-display text-[8rem] text-noise-border/20 relative z-10">SO</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent to-noise-card/50 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>

              {/* Info */}
              <div className="flex-1 p-8 flex flex-col justify-center gap-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">{look.label}</p>
                    <h2 className="font-display text-5xl text-noise-white leading-none">{look.title}</h2>
                    <p className="font-body text-noise-text text-sm mt-3 leading-relaxed">{look.desc}</p>
                  </div>
                  <span className="font-display text-6xl text-noise-border/20 leading-none">0{idx + 1}</span>
                </div>
                <div className={`flex items-center gap-4 transition-all duration-300 ${
                  active === look.id ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
                }`}>
                  {look.products.map(slug => (
                    <Link
                      key={slug}
                      href={`/shop/${slug}`}
                      className="btn-lime px-5 py-2.5 text-sm flex items-center gap-2"
                    >
                      SHOP LOOK <ArrowRight size={13}/>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
