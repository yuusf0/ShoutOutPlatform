"use client";
import { useState } from "react";
import { Package, Heart, MapPin, User, LogOut, ChevronRight, ShoppingBag } from "lucide-react";
import { formatPrice } from "@/lib/utils";

type Tab = "orders" | "wishlist" | "addresses" | "profile";

const MOCK_ORDERS = [
  { id: "SO-001", date: "2026-06-01", status: "DELIVERED", total: 2400, items: 2 },
  { id: "SO-002", date: "2026-06-10", status: "SHIPPED",   total: 1200, items: 1 },
];

export default function AccountPage() {
  const [tab, setTab] = useState<Tab>("orders");

  const NAV = [
    { id:"orders" as Tab,    label:"ORDERS",    icon:Package },
    { id:"wishlist" as Tab,  label:"WISHLIST",  icon:Heart },
    { id:"addresses" as Tab, label:"ADDRESSES", icon:MapPin },
    { id:"profile" as Tab,   label:"PROFILE",   icon:User },
  ];

  const STATUS_COLORS: Record<string,string> = {
    DELIVERED:"text-lime", SHIPPED:"text-yellow-400", PENDING:"text-noise-text", CANCELLED:"text-red-400"
  };

  return (
    <div className="min-h-screen pt-20">
      <div className="px-6 lg:px-12 py-8 border-b border-noise-border">
        <div className="max-w-7xl mx-auto flex items-end justify-between">
          <div>
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">MY ACCOUNT</p>
            <h1 className="font-display text-5xl text-noise-white">DASHBOARD</h1>
          </div>
          <button className="flex items-center gap-2 font-mono text-xs text-noise-text hover:text-lime transition-colors">
            <LogOut size={14}/> SIGN OUT
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10 grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-10">
        {/* Sidebar */}
        <div className="space-y-1">
          {NAV.map(({id,label,icon:Icon})=>(
            <button key={id} onClick={()=>setTab(id)}
              className={`admin-nav-item w-full flex items-center gap-3 px-4 py-3 text-left transition-all ${tab===id?"active":""}`}>
              <Icon size={15}/> <span className="font-mono text-xs tracking-wider">{label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div>
          {tab === "orders" && (
            <div>
              <h2 className="font-display text-3xl text-noise-white mb-6">ORDER HISTORY</h2>
              {MOCK_ORDERS.length === 0 ? (
                <div className="border border-dashed border-noise-border py-20 flex flex-col items-center gap-4">
                  <ShoppingBag size={32} className="text-noise-border"/>
                  <p className="font-display text-2xl text-noise-border">NO ORDERS YET</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {MOCK_ORDERS.map(order=>(
                    <div key={order.id} className="border border-noise-border bg-noise-card p-5 flex items-center justify-between">
                      <div className="flex items-center gap-6">
                        <div>
                          <p className="font-mono text-xs text-lime tracking-wider">{order.id}</p>
                          <p className="font-mono text-xs text-noise-text mt-0.5">{order.date}</p>
                        </div>
                        <div>
                          <p className="font-mono text-xs text-noise-text">{order.items} ITEM{order.items>1?"S":""}</p>
                          <p className="font-mono text-sm text-noise-white mt-0.5">{formatPrice(order.total)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={`font-mono text-xs tracking-wider ${STATUS_COLORS[order.status]}`}>{order.status}</span>
                        <ChevronRight size={14} className="text-noise-border"/>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {tab === "wishlist" && (
            <div>
              <h2 className="font-display text-3xl text-noise-white mb-6">SAVED PIECES</h2>
              <div className="border border-dashed border-noise-border py-20 flex flex-col items-center gap-4">
                <Heart size={32} className="text-noise-border"/>
                <p className="font-display text-2xl text-noise-border">NOTHING SAVED</p>
                <p className="font-mono text-xs text-noise-text">Browse the shop and save pieces</p>
              </div>
            </div>
          )}

          {tab === "addresses" && (
            <div>
              <h2 className="font-display text-3xl text-noise-white mb-6">SHIPPING ADDRESSES</h2>
              <div className="border border-dashed border-lime/20 py-10 flex flex-col items-center gap-3">
                <MapPin size={28} className="text-lime"/>
                <p className="font-mono text-xs text-noise-text">NO SAVED ADDRESSES</p>
                <button className="btn-lime px-6 py-2.5 text-sm mt-2">ADD ADDRESS</button>
              </div>
            </div>
          )}

          {tab === "profile" && (
            <div>
              <h2 className="font-display text-3xl text-noise-white mb-6">PROFILE</h2>
              <div className="space-y-4 max-w-md">
                {[["FIRST NAME",""],["LAST NAME",""],["EMAIL",""],["PHONE",""]].map(([label,val])=>(
                  <div key={label}>
                    <p className="font-mono text-xs text-noise-text tracking-ultrawide mb-2">{label}</p>
                    <input defaultValue={val} className="shoutout-input w-full px-4 py-3 text-sm font-mono" placeholder={label}/>
                  </div>
                ))}
                <button className="btn-lime px-8 py-3 text-base mt-4">SAVE CHANGES</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
