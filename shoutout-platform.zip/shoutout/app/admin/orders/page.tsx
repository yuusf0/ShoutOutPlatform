"use client";
import { useState } from "react";
import { Search, Package, Truck, CheckCircle, XCircle, RotateCcw } from "lucide-react";
import { formatPrice } from "@/lib/utils";

const ORDERS = [
  { id:"SO-008", customer:"Yusuf G.", email:"yusuf@example.com", item:"Logo Tee Black — M", total:1200, status:"PENDING",   date:"2026-06-22" },
  { id:"SO-007", customer:"Mert K.", email:"mert@example.com",   item:"Noise Hoodie — L",   total:2200, status:"SHIPPED",   date:"2026-06-21", tracking:"TK123456TR" },
  { id:"SO-006", customer:"Arda S.", email:"arda@example.com",   item:"Logo Tee White — S", total:1200, status:"DELIVERED", date:"2026-06-20" },
  { id:"SO-005", customer:"Kaan T.", email:"kaan@example.com",   item:"ShoutOut Cap",       total:800,  status:"DELIVERED", date:"2026-06-18" },
  { id:"SO-004", customer:"Bora Y.", email:"bora@example.com",   item:"Logo Tee Black — L", total:1200, status:"CANCELLED", date:"2026-06-17" },
];

const STATUS_CONFIG: Record<string,{icon:any,color:string,bg:string}> = {
  PENDING:   { icon:Package,    color:"text-noise-text",   bg:"border-noise-border bg-noise-dark" },
  SHIPPED:   { icon:Truck,      color:"text-yellow-400",   bg:"border-yellow-500/30 bg-yellow-500/5" },
  DELIVERED: { icon:CheckCircle,color:"text-lime",         bg:"border-lime/30 bg-lime/5" },
  CANCELLED: { icon:XCircle,    color:"text-red-400",      bg:"border-red-500/30 bg-red-500/5" },
};

export default function AdminOrders() {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("ALL");
  const [selectedOrder, setSelectedOrder] = useState<string|null>(null);

  const filtered = ORDERS.filter(o =>
    (filterStatus === "ALL" || o.status === filterStatus) &&
    (o.id.includes(search) || o.customer.toLowerCase().includes(search.toLowerCase()))
  );

  const selected = ORDERS.find(o => o.id === selectedOrder);

  return (
    <div className="space-y-6">
      <div>
        <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
        <h1 className="font-display text-5xl text-noise-white">ORDERS</h1>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {["ALL","PENDING","SHIPPED","DELIVERED"].map(s=>{
          const count = s==="ALL" ? ORDERS.length : ORDERS.filter(o=>o.status===s).length;
          return (
            <button key={s} onClick={()=>setFilterStatus(s)}
              className={`border p-4 text-left transition-all ${filterStatus===s?"border-lime bg-lime/5":"border-noise-border hover:border-noise-muted"}`}>
              <p className="font-display text-3xl text-noise-white">{count}</p>
              <p className="font-mono text-[10px] text-noise-text mt-1 tracking-wider">{s}</p>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6">
        {/* Orders list */}
        <div className="space-y-3">
          <div className="relative">
            <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-noise-text"/>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="SEARCH ORDERS..." className="shoutout-input w-full pl-10 pr-4 py-3 text-sm font-mono tracking-widest"/>
          </div>
          <div className="border border-noise-border bg-noise-card divide-y divide-noise-border">
            {filtered.map(order=>{
              const cfg = STATUS_CONFIG[order.status];
              const Icon = cfg.icon;
              return (
                <div key={order.id} onClick={()=>setSelectedOrder(order.id === selectedOrder ? null : order.id)}
                  className={`px-5 py-4 flex items-center justify-between cursor-pointer hover:bg-noise-dark/50 transition-colors ${selectedOrder===order.id?"bg-noise-dark/80":""}`}>
                  <div className="flex items-center gap-4">
                    <Icon size={14} className={cfg.color}/>
                    <div>
                      <p className="font-mono text-xs text-lime">{order.id}</p>
                      <p className="font-mono text-xs text-noise-white mt-0.5">{order.customer}</p>
                    </div>
                    <div className="hidden md:block">
                      <p className="font-mono text-xs text-noise-text">{order.item}</p>
                      <p className="font-mono text-[10px] text-noise-border mt-0.5">{order.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-mono text-sm text-noise-white">{formatPrice(order.total)}</span>
                    <span className={`font-mono text-[10px] px-2 py-0.5 border ${cfg.bg} ${cfg.color}`}>{order.status}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Order detail */}
        {selected ? (
          <div className="border border-noise-border bg-noise-card p-6 space-y-5 h-fit sticky top-8">
            <div className="flex items-center justify-between border-b border-noise-border pb-4">
              <h3 className="font-display text-2xl text-noise-white">{selected.id}</h3>
              <span className={`font-mono text-xs px-2 py-1 border ${STATUS_CONFIG[selected.status].bg} ${STATUS_CONFIG[selected.status].color}`}>{selected.status}</span>
            </div>
            <div className="space-y-3">
              {[["CUSTOMER",selected.customer],["EMAIL",selected.email],["ITEM",selected.item],["TOTAL",formatPrice(selected.total)],["DATE",selected.date]].map(([k,v])=>(
                <div key={k} className="flex justify-between">
                  <span className="font-mono text-[10px] text-noise-text tracking-wider">{k}</span>
                  <span className="font-mono text-xs text-noise-white">{v}</span>
                </div>
              ))}
              {selected.tracking && (
                <div className="flex justify-between">
                  <span className="font-mono text-[10px] text-noise-text tracking-wider">TRACKING</span>
                  <span className="font-mono text-xs text-lime">{selected.tracking}</span>
                </div>
              )}
            </div>
            <div className="space-y-2 pt-2 border-t border-noise-border">
              <p className="font-mono text-[10px] text-noise-text tracking-ultrawide mb-3">UPDATE STATUS</p>
              {["PENDING","SHIPPED","DELIVERED","CANCELLED"].map(s=>(
                <button key={s} className={`w-full py-2.5 text-xs font-mono tracking-wider border transition-all ${
                  selected.status===s?"border-lime text-lime bg-lime/5":"border-noise-border text-noise-text hover:border-noise-muted"
                }`}>{s}</button>
              ))}
              <button className="w-full py-2.5 text-xs font-mono border border-noise-border text-noise-text hover:border-noise-muted transition-all flex items-center justify-center gap-2 mt-2">
                <RotateCcw size={11}/> PROCESS REFUND
              </button>
            </div>
          </div>
        ) : (
          <div className="border border-dashed border-noise-border p-10 flex flex-col items-center justify-center gap-3 h-fit">
            <Package size={28} className="text-noise-border"/>
            <p className="font-mono text-xs text-noise-text">SELECT AN ORDER</p>
          </div>
        )}
      </div>
    </div>
  );
}
