"use client";
import { formatPrice } from "@/lib/utils";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from "recharts";

const DAILY = [
  {d:"MON",rev:0,orders:0},{d:"TUE",rev:0,orders:0},{d:"WED",rev:0,orders:0},
  {d:"THU",rev:1200,orders:1},{d:"FRI",rev:2400,orders:2},{d:"SAT",rev:3600,orders:3},{d:"SUN",rev:2800,orders:2},
];
const CATEGORY_DATA = [
  {name:"TEES",value:60,fill:"#C8FF00"},{name:"HOODIES",value:30,fill:"#888"},{name:"ACCESSORIES",value:10,fill:"#444"},
];
const TOP_PRODUCTS = [
  {name:"Logo Tee Black",sold:5,revenue:6000},
  {name:"Noise Hoodie",sold:3,revenue:6600},
  {name:"Logo Tee White",sold:2,revenue:2400},
  {name:"Shout Cap",sold:1,revenue:800},
];

const TooltipStyle = { background:"#111",border:"1px solid #1A1A1A",fontFamily:"Space Mono",fontSize:11 };

export default function AdminAnalytics() {
  return (
    <div className="space-y-8">
      <div>
        <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
        <h1 className="font-display text-5xl text-noise-white">ANALYTICS</h1>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {label:"TOTAL REVENUE",v:formatPrice(9900),sub:"Drop 001"},
          {label:"TOTAL ORDERS",v:"8",sub:"This week"},
          {label:"AVG ORDER VALUE",v:formatPrice(1237),sub:"Per order"},
          {label:"CONVERSION",v:"3.2%",sub:"Drop 001 page"},
        ].map(({label,v,sub})=>(
          <div key={label} className="border border-noise-border bg-noise-card p-5">
            <p className="font-mono text-[10px] text-noise-text tracking-ultrawide mb-2">{label}</p>
            <p className="font-display text-3xl text-lime">{v}</p>
            <p className="font-mono text-[10px] text-noise-border mt-1">{sub}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue chart */}
        <div className="lg:col-span-2 border border-noise-border bg-noise-card p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-display text-2xl text-noise-white">DAILY REVENUE</h3>
            <span className="font-mono text-xs text-noise-text">THIS WEEK</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={DAILY}>
              <defs>
                <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#C8FF00" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#C8FF00" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="d" tick={{fontSize:10,fontFamily:"Space Mono",fill:"#888"}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fontSize:10,fontFamily:"Space Mono",fill:"#888"}} axisLine={false} tickLine={false} tickFormatter={v=>`₺${v}`}/>
              <Tooltip contentStyle={TooltipStyle} formatter={(v)=>[formatPrice(Number(v)),"Revenue"]}/>
              <Area type="monotone" dataKey="rev" stroke="#C8FF00" strokeWidth={2} fill="url(#g)" dot={{fill:"#C8FF00",r:3}}/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Category pie */}
        <div className="border border-noise-border bg-noise-card p-6">
          <h3 className="font-display text-2xl text-noise-white mb-5">BY CATEGORY</h3>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={CATEGORY_DATA} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" paddingAngle={3}>
                {CATEGORY_DATA.map((entry,i)=><Cell key={i} fill={entry.fill}/>)}
              </Pie>
              <Tooltip contentStyle={TooltipStyle} formatter={(v)=>[`${Number(v)}%`,"Share"]}/>
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-4">
            {CATEGORY_DATA.map(c=>(
              <div key={c.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{background:c.fill}}/>
                  <span className="font-mono text-xs text-noise-text">{c.name}</span>
                </div>
                <span className="font-mono text-xs text-noise-white">{c.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top products */}
      <div className="border border-noise-border bg-noise-card">
        <div className="px-6 py-4 border-b border-noise-border">
          <h3 className="font-display text-2xl text-noise-white">TOP SELLING PIECES</h3>
        </div>
        <div className="divide-y divide-noise-border">
          {TOP_PRODUCTS.map((p,i)=>(
            <div key={p.name} className="px-6 py-4 flex items-center gap-6">
              <span className="font-display text-3xl text-noise-border w-8">0{i+1}</span>
              <div className="flex-1">
                <p className="font-display text-base text-noise-white tracking-wider">{p.name}</p>
                <div className="mt-1 bg-noise-dark h-1 w-full">
                  <div className="h-full bg-lime" style={{width:`${(p.sold/5)*100}%`}}/>
                </div>
              </div>
              <div className="text-right">
                <p className="font-mono text-xs text-lime">{formatPrice(p.revenue)}</p>
                <p className="font-mono text-[10px] text-noise-text mt-0.5">{p.sold} SOLD</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Orders bar */}
      <div className="border border-noise-border bg-noise-card p-6">
        <h3 className="font-display text-2xl text-noise-white mb-5">DAILY ORDERS</h3>
        <ResponsiveContainer width="100%" height={150}>
          <BarChart data={DAILY} barSize={24}>
            <XAxis dataKey="d" tick={{fontSize:10,fontFamily:"Space Mono",fill:"#888"}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fontSize:10,fontFamily:"Space Mono",fill:"#888"}} axisLine={false} tickLine={false} allowDecimals={false}/>
            <Tooltip contentStyle={TooltipStyle} formatter={(v)=>[Number(v),"Orders"]}/>
            <Bar dataKey="orders" fill="#C8FF00" radius={[2,2,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
