"use client";
import { useState } from "react";
import { Image, Type, Clock, Megaphone, Edit, Save, Plus } from "lucide-react";

type Panel = "hero"|"countdown"|"banners"|"modules";

export default function AdminContent() {
  const [panel, setPanel] = useState<Panel>("hero");
  const [heroTitle, setHeroTitle] = useState("THE NOISE IS COMING");
  const [heroSub, setHeroSub] = useState("DROP 001 — THE FIRST NOISE");
  const [dropDate, setDropDate] = useState("2026-06-25T12:00");
  const [saved, setSaved] = useState(false);

  const save = () => { setSaved(true); setTimeout(()=>setSaved(false),2000); };

  const PANELS = [
    {id:"hero" as Panel,    label:"HERO BANNER",  icon:Image},
    {id:"countdown" as Panel,label:"COUNTDOWN",   icon:Clock},
    {id:"banners" as Panel, label:"DROP BANNERS", icon:Megaphone},
    {id:"modules" as Panel, label:"HOMEPAGE",     icon:Type},
  ];

  return (
    <div className="space-y-6">
      <div>
        <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
        <h1 className="font-display text-5xl text-noise-white">CONTENT</h1>
      </div>

      <div className="flex gap-2 flex-wrap">
        {PANELS.map(({id,label,icon:Icon})=>(
          <button key={id} onClick={()=>setPanel(id)}
            className={`flex items-center gap-2 px-4 py-2.5 border font-mono text-xs tracking-wider transition-all ${
              panel===id?"border-lime text-lime bg-lime/5":"border-noise-border text-noise-text hover:border-noise-muted"
            }`}>
            <Icon size={13}/>{label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Editor */}
        <div className="border border-noise-border bg-noise-card p-6 space-y-5">
          {panel === "hero" && (
            <>
              <h3 className="font-display text-2xl text-noise-white">HERO BANNER</h3>
              <div>
                <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">MAIN HEADLINE</label>
                <input value={heroTitle} onChange={e=>setHeroTitle(e.target.value)} className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
              </div>
              <div>
                <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">SUBTEXT</label>
                <input value={heroSub} onChange={e=>setHeroSub(e.target.value)} className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
              </div>
              <div>
                <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">BACKGROUND IMAGE</label>
                <div className="border border-dashed border-noise-border p-8 flex flex-col items-center gap-3">
                  <Image size={28} className="text-noise-border"/>
                  <p className="font-mono text-xs text-noise-text">DRAG & DROP OR CLICK TO UPLOAD</p>
                  <button className="btn-outline px-4 py-2 text-xs">BROWSE FILES</button>
                </div>
              </div>
            </>
          )}

          {panel === "countdown" && (
            <>
              <h3 className="font-display text-2xl text-noise-white">DROP COUNTDOWN</h3>
              <div>
                <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">DROP DATE & TIME</label>
                <input type="datetime-local" value={dropDate} onChange={e=>setDropDate(e.target.value)} className="shoutout-input w-full px-4 py-3 text-sm font-mono"/>
              </div>
              <div>
                <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">COUNTDOWN LABEL</label>
                <input defaultValue="DROP IN" className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
              </div>
              <div className="flex items-center gap-3">
                <input type="checkbox" id="showCountdown" defaultChecked className="accent-lime"/>
                <label htmlFor="showCountdown" className="font-mono text-xs text-noise-text cursor-pointer">SHOW COUNTDOWN ON HOMEPAGE</label>
              </div>
            </>
          )}

          {panel === "banners" && (
            <>
              <h3 className="font-display text-2xl text-noise-white">DROP BANNERS</h3>
              <div className="space-y-3">
                {["TICKER TAPE TEXT","ANNOUNCEMENT BAR"].map(field=>(
                  <div key={field}>
                    <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">{field}</label>
                    <input defaultValue="THE NOISE IS COMING — DROP 001 — LIMITED PIECES — NO RESTOCK"
                      className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
                  </div>
                ))}
              </div>
            </>
          )}

          {panel === "modules" && (
            <>
              <h3 className="font-display text-2xl text-noise-white">HOMEPAGE MODULES</h3>
              <div className="space-y-3">
                {[
                  {label:"HERO SECTION",active:true},
                  {label:"TICKER TAPE",active:true},
                  {label:"DROP SECTION",active:true},
                  {label:"CAMPAIGN SECTION",active:true},
                  {label:"LOOKBOOK SECTION",active:true},
                  {label:"COMMUNITY SECTION",active:true},
                ].map(m=>(
                  <div key={m.label} className="flex items-center justify-between p-3 border border-noise-border">
                    <span className="font-mono text-xs text-noise-white tracking-wider">{m.label}</span>
                    <div className="flex items-center gap-3">
                      <button className="text-noise-text hover:text-lime transition-colors"><Edit size={12}/></button>
                      <div className={`w-8 h-4 rounded-full transition-colors cursor-pointer ${m.active?"bg-lime":"bg-noise-muted"} flex items-center px-0.5`}>
                        <div className={`w-3 h-3 rounded-full bg-noise-black transition-transform ${m.active?"translate-x-4":""}`}/>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          <button onClick={save} className="btn-lime w-full py-3 text-sm flex items-center justify-center gap-2">
            <Save size={14}/> {saved ? "SAVED ✓" : "SAVE CHANGES"}
          </button>
        </div>

        {/* Preview */}
        <div className="border border-noise-border bg-noise-dark p-4">
          <p className="font-mono text-[10px] text-noise-text tracking-ultrawide mb-4 border-b border-noise-border pb-3">LIVE PREVIEW</p>
          <div className="bg-noise-black border border-noise-border/50 aspect-video flex flex-col overflow-hidden">
            {/* Mini hero preview */}
            <div className="flex-1 flex flex-col items-start justify-end p-4 bg-grid-noise bg-grid relative">
              <div className="absolute inset-0 bg-gradient-to-t from-noise-black/80 to-transparent"/>
              <div className="relative">
                <p className="font-mono text-[6px] text-lime tracking-widest">{heroSub}</p>
                <p className="font-display text-lg text-noise-white leading-none mt-1">SHOUT</p>
                <p className="font-display text-lg text-lime leading-none">OUT</p>
              </div>
            </div>
            <div className="bg-lime py-1 flex items-center overflow-hidden">
              <p className="font-mono text-[6px] text-noise-black whitespace-nowrap">{heroTitle} — {heroTitle} — {heroTitle} —</p>
            </div>
          </div>
          <p className="font-mono text-[10px] text-noise-border mt-3 text-center">HOMEPAGE PREVIEW (APPROXIMATE)</p>
        </div>
      </div>
    </div>
  );
}
