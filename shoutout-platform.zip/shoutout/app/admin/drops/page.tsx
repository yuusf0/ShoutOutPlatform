"use client";
import { useState } from "react";
import { Zap, Plus, Calendar, Package } from "lucide-react";
import { MOCK_DROPS, formatPrice } from "@/lib/utils";

export default function AdminDrops() {
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
          <h1 className="font-display text-5xl text-noise-white">DROPS</h1>
        </div>
        <button onClick={()=>setShowForm(!showForm)} className="btn-lime px-5 py-2.5 text-sm flex items-center gap-2">
          <Plus size={15}/> CREATE DROP
        </button>
      </div>

      {showForm && (
        <div className="border border-lime/20 bg-noise-card p-6 space-y-4">
          <h3 className="font-display text-2xl text-noise-white">NEW DROP</h3>
          <div className="grid grid-cols-2 gap-4">
            <input placeholder="DROP NAME" className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
            <input placeholder="SLUG (drop-002)" className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
            <input type="datetime-local" className="shoutout-input px-4 py-3 text-sm font-mono col-span-2"/>
            <textarea placeholder="DESCRIPTION" className="shoutout-input col-span-2 px-4 py-3 text-sm font-mono resize-none h-20"/>
          </div>
          <div className="flex gap-3">
            <button className="btn-lime px-6 py-2.5 text-sm">CREATE</button>
            <button onClick={()=>setShowForm(false)} className="btn-outline px-6 py-2.5 text-sm">CANCEL</button>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {MOCK_DROPS.map(drop=>(
          <div key={drop.id} className="border border-noise-border bg-noise-card p-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-2 h-2 bg-lime rounded-full animate-pulse"/>
                  <span className="font-mono text-xs text-lime tracking-wider">ACTIVE</span>
                </div>
                <h3 className="font-display text-3xl text-noise-white mb-1">{drop.name}</h3>
                <p className="font-mono text-xs text-noise-text">{drop.description}</p>
              </div>
              <div className="flex items-center gap-2">
                <button className="btn-outline px-4 py-2 text-xs">EDIT</button>
                <button className="border border-noise-border px-4 py-2 text-xs font-mono text-noise-text hover:text-lime hover:border-lime transition-all">ARCHIVE</button>
              </div>
            </div>
            <div className="mt-5 pt-5 border-t border-noise-border grid grid-cols-3 gap-4">
              {[
                {icon:Calendar, label:"DROP DATE",  v:drop.dropDate.toLocaleDateString()},
                {icon:Package,  label:"PRODUCTS",   v:"4 PIECES"},
                {icon:Zap,      label:"REVENUE",    v:formatPrice(9900)},
              ].map(({icon:Icon,label,v})=>(
                <div key={label} className="flex items-center gap-3">
                  <Icon size={14} className="text-lime"/>
                  <div>
                    <p className="font-mono text-[10px] text-noise-text">{label}</p>
                    <p className="font-mono text-xs text-noise-white mt-0.5">{v}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
