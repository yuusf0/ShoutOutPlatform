"use client";
import { useState } from "react";
import { Plus, Search, Edit, Trash2, Eye, MoreHorizontal } from "lucide-react";
import { MOCK_PRODUCTS, formatPrice, RARITY_CONFIG } from "@/lib/utils";
import Link from "next/link";

export default function AdminProducts() {
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name:"", price:"", category:"TEES", rarity:"COMMON", description:"", isLimited:false });

  const filtered = MOCK_PRODUCTS.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
          <h1 className="font-display text-5xl text-noise-white">PRODUCTS</h1>
        </div>
        <button onClick={()=>setShowForm(!showForm)} className="btn-lime px-5 py-2.5 text-sm flex items-center gap-2">
          <Plus size={15}/> NEW PRODUCT
        </button>
      </div>

      {/* Create form */}
      {showForm && (
        <div className="border border-lime/20 bg-noise-card p-6 space-y-4">
          <h3 className="font-display text-2xl text-noise-white">CREATE PRODUCT</h3>
          <div className="grid grid-cols-2 gap-4">
            <input placeholder="PRODUCT NAME" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
            <input placeholder="PRICE (₺)" value={form.price} onChange={e=>setForm(f=>({...f,price:e.target.value}))} className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest" type="number"/>
            <select value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))} className="shoutout-input px-4 py-3 text-sm font-mono bg-noise-dark cursor-pointer">
              {["TEES","HOODIES","ACCESSORIES"].map(c=><option key={c}>{c}</option>)}
            </select>
            <select value={form.rarity} onChange={e=>setForm(f=>({...f,rarity:e.target.value}))} className="shoutout-input px-4 py-3 text-sm font-mono bg-noise-dark cursor-pointer">
              {["COMMON","RARE","EXCLUSIVE","ONE_OF_ONE"].map(r=><option key={r}>{r}</option>)}
            </select>
            <textarea placeholder="DESCRIPTION" value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} className="shoutout-input col-span-2 px-4 py-3 text-sm font-mono tracking-widest resize-none h-24"/>
          </div>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.isLimited} onChange={e=>setForm(f=>({...f,isLimited:e.target.checked}))} className="accent-lime"/>
              <span className="font-mono text-xs text-noise-text">LIMITED EDITION</span>
            </label>
          </div>
          <div className="flex gap-3">
            <button className="btn-lime px-6 py-2.5 text-sm">CREATE PRODUCT</button>
            <button onClick={()=>setShowForm(false)} className="btn-outline px-6 py-2.5 text-sm">CANCEL</button>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-noise-text"/>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="SEARCH PRODUCTS..." className="shoutout-input w-full pl-10 pr-4 py-3 text-sm font-mono tracking-widest"/>
      </div>

      {/* Table */}
      <div className="border border-noise-border bg-noise-card overflow-hidden">
        <div className="grid grid-cols-[1fr_auto_auto_auto_auto_auto] gap-0 border-b border-noise-border px-6 py-3">
          {["PRODUCT","CATEGORY","PRICE","RARITY","STOCK","ACTIONS"].map(h=>(
            <span key={h} className="font-mono text-[10px] text-noise-text tracking-ultrawide">{h}</span>
          ))}
        </div>
        <div className="divide-y divide-noise-border">
          {filtered.map(product=>{
            const rarity = RARITY_CONFIG[product.rarity as keyof typeof RARITY_CONFIG];
            return (
              <div key={product.id} className="grid grid-cols-[1fr_auto_auto_auto_auto_auto] gap-6 items-center px-6 py-4 hover:bg-noise-dark/50 transition-colors">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-12 bg-noise-dark border border-noise-border flex items-center justify-center flex-shrink-0">
                    <span className="font-display text-sm text-noise-border/50">SO</span>
                  </div>
                  <div className="min-w-0">
                    <p className="font-display text-sm text-noise-white tracking-wider truncate">{product.name}</p>
                    {product.isLimited && <span className="font-mono text-[9px] text-lime">LIMITED</span>}
                  </div>
                </div>
                <span className="font-mono text-xs text-noise-text">{product.category}</span>
                <span className="font-mono text-sm text-lime">{formatPrice(product.price)}</span>
                <span className={`font-mono text-[10px] px-2 py-0.5 ${rarity?.class}`}>{rarity?.label}</span>
                <span className="font-mono text-xs text-noise-text">17</span>
                <div className="flex items-center gap-2">
                  <Link href={`/shop/${product.slug}`} className="text-noise-text hover:text-lime transition-colors p-1"><Eye size={13}/></Link>
                  <button className="text-noise-text hover:text-lime transition-colors p-1"><Edit size={13}/></button>
                  <button className="text-noise-text hover:text-red-400 transition-colors p-1"><Trash2 size={13}/></button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
