"use client";
import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Package, ShoppingCart, Users, BarChart3,
  Settings, Layers, Megaphone, ChevronLeft, ChevronRight,
  Zap, Tag, Image
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { label:"DASHBOARD",  href:"/admin",              icon:LayoutDashboard },
  { label:"PRODUCTS",   href:"/admin/products",      icon:Package },
  { label:"DROPS",      href:"/admin/drops",          icon:Zap },
  { label:"ORDERS",     href:"/admin/orders",         icon:ShoppingCart },
  { label:"COMMUNITY",  href:"/admin/community",      icon:Users },
  { label:"ANALYTICS",  href:"/admin/analytics",      icon:BarChart3 },
  { label:"CONTENT",    href:"/admin/content",        icon:Image },
  { label:"SETTINGS",   href:"/admin/settings",       icon:Settings },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();

  return (
    <div className="flex h-screen bg-noise-black overflow-hidden">
      {/* Sidebar */}
      <aside className={cn(
        "flex-shrink-0 bg-noise-dark border-r border-noise-border flex flex-col transition-all duration-300",
        collapsed ? "w-16" : "w-56"
      )}>
        {/* Logo */}
        <div className={cn("flex items-center border-b border-noise-border h-14 px-4", collapsed ? "justify-center" : "justify-between")}>
          {!collapsed && (
            <div className="flex items-baseline gap-1">
              <span className="font-display text-lg text-noise-white">SHOUTOUT</span>
              <span className="text-lime text-xs font-mono">OS</span>
            </div>
          )}
          <button onClick={() => setCollapsed(!collapsed)} className="text-noise-text hover:text-lime transition-colors p-1">
            {collapsed ? <ChevronRight size={16}/> : <ChevronLeft size={16}/>}
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 space-y-0.5 px-2">
          {NAV.map(({ label, href, icon: Icon }) => {
            const active = pathname === href || (href !== "/admin" && pathname.startsWith(href));
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "admin-nav-item flex items-center gap-3 px-3 py-2.5 rounded-sm",
                  active ? "active" : "",
                  collapsed ? "justify-center" : ""
                )}
                title={collapsed ? label : undefined}
              >
                <Icon size={15} className="flex-shrink-0" />
                {!collapsed && <span className="font-mono text-xs tracking-wider">{label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="border-t border-noise-border p-4">
          {!collapsed ? (
            <div>
              <p className="font-mono text-[10px] text-noise-border tracking-wider">SHOUTOUT OS v1.0</p>
              <p className="font-mono text-[10px] text-noise-border">DROP 001 ACTIVE</p>
            </div>
          ) : (
            <Layers size={14} className="text-noise-border mx-auto"/>
          )}
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        <div className="p-8">{children}</div>
      </main>
    </div>
  );
}
