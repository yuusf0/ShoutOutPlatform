"use client";
import { BarChart3, ShoppingCart, Package, Users, TrendingUp, Zap, ArrowUpRight } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { formatPrice } from "@/lib/utils";
import Link from "next/link";

const REVENUE_DATA = [
  { day:"MON", revenue:0 }, { day:"TUE", revenue:0 }, { day:"WED", revenue:0 },
  { day:"THU", revenue:1200 }, { day:"FRI", revenue:2400 }, { day:"SAT", revenue:3600 }, { day:"SUN", revenue:2800 },
];

const STATS = [
  { label:"TOTAL REVENUE",  value:formatPrice(9900), icon:BarChart3, change:"+∞%", sub:"First week" },
  { label:"ORDERS",         value:"8",               icon:ShoppingCart, change:"+8", sub:"This week" },
  { label:"PRODUCTS",       value:"4",               icon:Package, change:"DROP 001", sub:"Active" },
  { label:"EARLY ACCESS",   value:"423",             icon:Users, change:"77 left", sub:"500 cap" },
];

export default function AdminDashboard() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-end justify-between">
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
          <h1 className="font-display text-5xl text-noise-white">DASHBOARD</h1>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-lime rounded-full animate-pulse"/>
          <span className="font-mono text-xs text-lime">DROP 001 LIVE</span>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {STATS.map(({label,value,icon:Icon,change,sub})=>(
          <div key={label} className="border border-noise-border bg-noise-card p-5 space-y-3">
            <div className="flex items-center justify-between">
              <Icon size={16} className="text-lime"/>
              <span className="font-mono text-xs text-lime">{change}</span>
            </div>
            <div>
              <p className="font-display text-3xl text-noise-white">{value}</p>
              <p className="font-mono text-[10px] text-noise-text tracking-wider mt-0.5">{label}</p>
            </div>
            <p className="font-mono text-[10px] text-noise-border">{sub}</p>
          </div>
        ))}
      </div>

      {/* Revenue chart */}
      <div className="border border-noise-border bg-noise-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="font-mono text-xs text-noise-text tracking-ultrawide mb-1">THIS WEEK</p>
            <h3 className="font-display text-2xl text-noise-white">REVENUE</h3>
          </div>
          <span className="font-display text-3xl text-lime">{formatPrice(9900)}</span>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={REVENUE_DATA}>
            <defs>
              <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#C8FF00" stopOpacity={0.15}/>
                <stop offset="95%" stopColor="#C8FF00" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis dataKey="day" tick={{fontSize:10,fontFamily:"Space Mono",fill:"#888"}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fontSize:10,fontFamily:"Space Mono",fill:"#888"}} axisLine={false} tickLine={false} tickFormatter={v=>`₺${v}`}/>
            <Tooltip contentStyle={{background:"#111",border:"1px solid #1A1A1A",fontFamily:"Space Mono",fontSize:11}} formatter={(v)=>[formatPrice(Number(v)),"Revenue"]}/>
            <Area type="monotone" dataKey="revenue" stroke="#C8FF00" strokeWidth={2} fill="url(#rev)" dot={{fill:"#C8FF00",r:3}}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {[
          { label:"ADD PRODUCT",    href:"/admin/products", icon:Package,     desc:"Create new piece" },
          { label:"NEW DROP",       href:"/admin/drops",    icon:Zap,         desc:"Schedule a drop" },
          { label:"VIEW ORDERS",    href:"/admin/orders",   icon:ShoppingCart,desc:"8 pending orders" },
        ].map(({label,href,icon:Icon,desc})=>(
          <Link key={label} href={href} className="border border-noise-border bg-noise-card p-5 hover:border-lime/40 transition-all group flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Icon size={18} className="text-lime"/>
              <div>
                <p className="font-mono text-xs text-noise-white tracking-wider">{label}</p>
                <p className="font-mono text-[10px] text-noise-text mt-0.5">{desc}</p>
              </div>
            </div>
            <ArrowUpRight size={14} className="text-noise-border group-hover:text-lime transition-colors"/>
          </Link>
        ))}
      </div>

      {/* Recent orders */}
      <div className="border border-noise-border bg-noise-card">
        <div className="flex items-center justify-between px-6 py-4 border-b border-noise-border">
          <h3 className="font-display text-xl text-noise-white">RECENT ORDERS</h3>
          <Link href="/admin/orders" className="font-mono text-xs text-lime hover:text-noise-white transition-colors flex items-center gap-1">
            VIEW ALL <ArrowUpRight size={11}/>
          </Link>
        </div>
        <div className="divide-y divide-noise-border">
          {[
            { id:"SO-008", customer:"Yusuf G.",  item:"Logo Tee Black — M", total:1200, status:"PENDING" },
            { id:"SO-007", customer:"Mert K.",   item:"Noise Hoodie — L",   total:2200, status:"SHIPPED" },
            { id:"SO-006", customer:"Arda S.",   item:"Logo Tee White — S", total:1200, status:"DELIVERED" },
          ].map(order=>(
            <div key={order.id} className="px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-6">
                <span className="font-mono text-xs text-lime">{order.id}</span>
                <span className="font-mono text-xs text-noise-text">{order.customer}</span>
                <span className="font-mono text-xs text-noise-white">{order.item}</span>
              </div>
              <div className="flex items-center gap-6">
                <span className="font-mono text-sm text-noise-white">{formatPrice(order.total)}</span>
                <span className={`font-mono text-xs px-2 py-0.5 border ${
                  order.status==="DELIVERED"?"border-lime/30 text-lime bg-lime/5":
                  order.status==="SHIPPED"?"border-yellow-500/30 text-yellow-400":"border-noise-border text-noise-text"
                }`}>{order.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
