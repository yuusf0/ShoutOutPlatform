"use client";
import { useState } from "react";
import { Users, Mail, Star, MessageSquare, Search, Plus, Download } from "lucide-react";

const WHITELIST = [
  {email:"yusuf@example.com", joined:"2026-06-20", isVIP:true,  drop:"DROP 001"},
  {email:"mert@example.com",  joined:"2026-06-21", isVIP:false, drop:"DROP 001"},
  {email:"arda@example.com",  joined:"2026-06-21", isVIP:true,  drop:"DROP 001"},
  {email:"kaan@example.com",  joined:"2026-06-22", isVIP:false, drop:"DROP 001"},
  {email:"bora@example.com",  joined:"2026-06-22", isVIP:false, drop:"DROP 001"},
];
const NEWSLETTER = [
  {email:"sub1@example.com",date:"2026-06-20"},{email:"sub2@example.com",date:"2026-06-21"},
  {email:"sub3@example.com",date:"2026-06-21"},{email:"sub4@example.com",date:"2026-06-22"},
];

type Tab = "whitelist"|"newsletter"|"discord";
export default function AdminCommunity() {
  const [tab, setTab] = useState<Tab>("whitelist");
  const [search, setSearch] = useState("");
  const [newEmail, setNewEmail] = useState("");

  const TABS = [
    {id:"whitelist" as Tab, label:"EARLY ACCESS", icon:Star, count:WHITELIST.length},
    {id:"newsletter" as Tab,label:"NEWSLETTER",   icon:Mail, count:NEWSLETTER.length},
    {id:"discord" as Tab,   label:"DISCORD",      icon:MessageSquare, count:423},
  ];

  return (
    <div className="space-y-6">
      <div>
        <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
        <h1 className="font-display text-5xl text-noise-white">COMMUNITY</h1>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-3 gap-4">
        {[{label:"EARLY ACCESS",v:"423",sub:"77 spots left"},{label:"NEWSLETTER",v:"4",sub:"Subscribers"},{label:"DISCORD",v:"423",sub:"Members"}].map(({label,v,sub})=>(
          <div key={label} className="border border-noise-border bg-noise-card p-5">
            <p className="font-mono text-[10px] text-noise-text tracking-ultrawide mb-2">{label}</p>
            <p className="font-display text-3xl text-lime">{v}</p>
            <p className="font-mono text-[10px] text-noise-border mt-1">{sub}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {TABS.map(({id,label,icon:Icon,count})=>(
          <button key={id} onClick={()=>setTab(id)}
            className={`flex items-center gap-2 px-4 py-2.5 border font-mono text-xs tracking-wider transition-all ${
              tab===id?"border-lime text-lime bg-lime/5":"border-noise-border text-noise-text hover:border-noise-muted"
            }`}>
            <Icon size={13}/>{label}
            <span className={`text-[10px] px-1.5 py-0.5 rounded-sm ${tab===id?"bg-lime text-noise-black":"bg-noise-dark text-noise-border"}`}>{count}</span>
          </button>
        ))}
      </div>

      {tab === "whitelist" && (
        <div className="space-y-4">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-noise-text"/>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="SEARCH EMAIL..." className="shoutout-input w-full pl-9 pr-4 py-2.5 text-xs font-mono tracking-widest"/>
            </div>
            <div className="flex gap-2">
              <input value={newEmail} onChange={e=>setNewEmail(e.target.value)} placeholder="ADD EMAIL..." className="shoutout-input px-3 py-2.5 text-xs font-mono tracking-widest w-52"/>
              <button className="btn-lime px-4 py-2.5 text-xs flex items-center gap-1.5"><Plus size={12}/>ADD</button>
            </div>
            <button className="btn-outline px-4 py-2.5 text-xs flex items-center gap-1.5"><Download size={12}/>EXPORT</button>
          </div>
          {/* Progress */}
          <div className="border border-noise-border bg-noise-card p-4">
            <div className="flex justify-between mb-2">
              <span className="font-mono text-xs text-noise-text">WHITELIST CAPACITY</span>
              <span className="font-mono text-xs text-lime">423 / 500</span>
            </div>
            <div className="h-1.5 bg-noise-dark w-full rounded-full overflow-hidden">
              <div className="h-full bg-lime rounded-full" style={{width:"84.6%"}}/>
            </div>
          </div>
          <div className="border border-noise-border bg-noise-card divide-y divide-noise-border">
            {WHITELIST.filter(m=>m.email.includes(search)).map(member=>(
              <div key={member.email} className="px-5 py-3.5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-7 h-7 bg-noise-dark border border-noise-border flex items-center justify-center">
                    <Users size={12} className="text-noise-text"/>
                  </div>
                  <div>
                    <p className="font-mono text-xs text-noise-white">{member.email}</p>
                    <p className="font-mono text-[10px] text-noise-text mt-0.5">Joined {member.joined}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-[10px] text-noise-text">{member.drop}</span>
                  {member.isVIP && <span className="font-mono text-[10px] text-lime border border-lime/30 px-2 py-0.5 bg-lime/5">VIP</span>}
                  <button className="font-mono text-[10px] text-noise-text hover:text-lime transition-colors">PROMOTE TO VIP</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "newsletter" && (
        <div className="border border-noise-border bg-noise-card divide-y divide-noise-border">
          <div className="px-5 py-3 border-b border-noise-border flex justify-between items-center">
            <span className="font-mono text-xs text-noise-text">{NEWSLETTER.length} SUBSCRIBERS</span>
            <button className="btn-outline px-3 py-1.5 text-xs flex items-center gap-1.5"><Download size={11}/>EXPORT CSV</button>
          </div>
          {NEWSLETTER.map(sub=>(
            <div key={sub.email} className="px-5 py-3 flex items-center justify-between">
              <span className="font-mono text-xs text-noise-white">{sub.email}</span>
              <span className="font-mono text-[10px] text-noise-text">{sub.date}</span>
            </div>
          ))}
        </div>
      )}

      {tab === "discord" && (
        <div className="border border-noise-border bg-noise-card p-8 text-center space-y-4">
          <MessageSquare size={40} className="text-lime mx-auto"/>
          <h3 className="font-display text-3xl text-noise-white">DISCORD SERVER</h3>
          <p className="font-mono text-xs text-noise-text">423 members active</p>
          <div className="grid grid-cols-3 gap-4 mt-6">
            {[{label:"MEMBERS",v:"423"},{label:"ONLINE NOW",v:"38"},{label:"INVITES SENT",v:"61"}].map(({label,v})=>(
              <div key={label} className="border border-noise-border bg-noise-dark p-4">
                <p className="font-display text-3xl text-lime">{v}</p>
                <p className="font-mono text-[10px] text-noise-text mt-1">{label}</p>
              </div>
            ))}
          </div>
          <a href="https://discord.gg/shoutout" target="_blank" className="btn-lime inline-flex items-center gap-2 px-6 py-3 text-sm mt-4">
            <MessageSquare size={15}/> OPEN SERVER
          </a>
        </div>
      )}
    </div>
  );
}
