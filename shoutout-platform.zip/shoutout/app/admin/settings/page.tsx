"use client";
import { useState } from "react";
import { Save } from "lucide-react";

export default function AdminSettings() {
  const [saved, setSaved] = useState(false);
  const save = () => { setSaved(true); setTimeout(()=>setSaved(false),2000); };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">SHOUTOUT OS</p>
        <h1 className="font-display text-5xl text-noise-white">SETTINGS</h1>
      </div>

      {[
        { title:"STORE", fields:[
          {label:"STORE NAME", val:"ShoutOut™"},
          {label:"DOMAIN", val:"shoutout.tr"},
          {label:"EMAIL", val:"info@shoutout.tr"},
          {label:"SUPPORT EMAIL", val:"support@shoutout.tr"},
        ]},
        { title:"SHIPPING", fields:[
          {label:"FREE SHIPPING THRESHOLD (₺)", val:"1500"},
          {label:"STANDARD SHIPPING COST (₺)", val:"50"},
          {label:"EXPRESS SHIPPING COST (₺)", val:"150"},
        ]},
        { title:"PAYMENT", fields:[
          {label:"STRIPE PUBLIC KEY", val:"pk_live_..."},
          {label:"CURRENCY", val:"TRY"},
        ]},
      ].map(({title,fields})=>(
        <div key={title} className="border border-noise-border bg-noise-card p-6 space-y-4">
          <h3 className="font-display text-2xl text-noise-white border-b border-noise-border pb-3">{title}</h3>
          {fields.map(({label,val})=>(
            <div key={label}>
              <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">{label}</label>
              <input defaultValue={val} className="shoutout-input w-full px-4 py-3 text-sm font-mono"/>
            </div>
          ))}
        </div>
      ))}

      <button onClick={save} className="btn-lime px-8 py-3 text-base flex items-center gap-2">
        <Save size={16}/> {saved ? "SAVED ✓" : "SAVE ALL SETTINGS"}
      </button>
    </div>
  );
}
