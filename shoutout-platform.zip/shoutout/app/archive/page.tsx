import { Lock } from "lucide-react";

export default function ArchivePage() {
  return (
    <div className="min-h-screen pt-20">
      <div className="px-6 lg:px-12 py-12 border-b border-noise-border">
        <div className="max-w-7xl mx-auto">
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-3">HISTORY</p>
          <h1 className="font-display text-[clamp(3.5rem,9vw,7rem)] text-noise-white leading-none">ARCHIVE</h1>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-32 flex flex-col items-center justify-center text-center">
        <Lock size={48} className="text-noise-border mb-8"/>
        <h2 className="font-display text-5xl text-noise-border mb-4">NOTHING ARCHIVED YET</h2>
        <p className="font-mono text-xs text-noise-text tracking-ultrawide">DROP 001 IS WHERE IT BEGINS</p>
        <div className="mt-12 w-px h-24 bg-gradient-to-b from-lime/30 to-transparent mx-auto" />
      </div>
    </div>
  );
}
