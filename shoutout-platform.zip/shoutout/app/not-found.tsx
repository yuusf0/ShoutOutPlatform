import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-noise-black flex flex-col items-center justify-center text-center px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-noise bg-grid opacity-20" />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
        <span className="font-display text-[30vw] text-noise-border/10 leading-none">404</span>
      </div>
      <div className="relative z-10">
        <p className="font-mono text-xs text-lime tracking-ultrawide mb-4 animate-pulse">PAGE NOT FOUND</p>
        <h1 className="font-display text-[clamp(4rem,12vw,9rem)] text-noise-white leading-none mb-4">
          THE<br/>NOISE<br/>
          <span className="text-lime">MOVED.</span>
        </h1>
        <p className="font-body text-noise-text mb-10 max-w-xs mx-auto">
          This page doesn't exist. Maybe it dropped and sold out. Check the homepage.
        </p>
        <Link href="/" className="btn-lime inline-flex items-center gap-3 px-8 py-4 text-lg">
          BACK TO HOMEPAGE <ArrowRight size={18}/>
        </Link>
      </div>
    </div>
  );
}
