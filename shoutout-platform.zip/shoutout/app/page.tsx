import Hero from "@/components/home/Hero";
import MarqueeTicker from "@/components/home/MarqueeTicker";
import DropSection from "@/components/home/DropSection";
import CampaignSection from "@/components/home/CampaignSection";
import LookbookSection from "@/components/home/LookbookSection";
import CommunitySection from "@/components/home/CommunitySection";

export default function HomePage() {
  return (
    <>
      <Hero />
      <MarqueeTicker />
      <DropSection />
      <CampaignSection />
      <LookbookSection />
      <CommunitySection />
    </>
  );
}
