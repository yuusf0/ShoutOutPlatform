"use client";
import { useState } from "react";
import { useCartStore } from "@/store/cart";
import { formatPrice } from "@/lib/utils";
import { Lock, ChevronRight, ArrowLeft } from "lucide-react";
import Link from "next/link";
import toast from "react-hot-toast";

type Step = "information" | "shipping" | "payment";

export default function CheckoutPage() {
  const { items, totalPrice, clearCart } = useCartStore();
  const [step, setStep] = useState<Step>("information");
  const [form, setForm] = useState({ email:"", firstName:"", lastName:"", address:"", city:"", zip:"", country:"Turkey", phone:"" });
  const [shipping, setShipping] = useState("standard");
  const [discount, setDiscount] = useState("");
  const [discountApplied, setDiscountApplied] = useState(false);
  const total = totalPrice();
  const shippingCost = shipping === "express" ? 150 : total > 1500 ? 0 : 50;
  const discountAmount = discountApplied ? total * 0.1 : 0;
  const finalTotal = total + shippingCost - discountAmount;

  const applyDiscount = () => {
    if (discount.toUpperCase() === "NOISE10") { setDiscountApplied(true); toast.success("10% discount applied"); }
    else toast.error("Invalid code");
  };

  const handlePlaceOrder = () => {
    toast.success("Order placed! Check your email.");
    clearCart();
  };

  const STEPS: Step[] = ["information", "shipping", "payment"];
  const stepIdx = STEPS.indexOf(step);

  return (
    <div className="min-h-screen pt-20 bg-noise-black">
      {/* Header */}
      <div className="border-b border-noise-border px-6 lg:px-12 py-5 flex items-center justify-between">
        <Link href="/" className="font-display text-xl tracking-wider text-noise-white flex items-baseline gap-1">
          SHOUTOUT <span className="text-lime text-xs font-mono">™</span>
        </Link>
        <div className="flex items-center gap-3">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <span className={`font-mono text-xs tracking-widest uppercase ${i <= stepIdx ? "text-lime" : "text-noise-border"}`}>{s}</span>
              {i < STEPS.length-1 && <ChevronRight size={12} className="text-noise-border"/>}
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 lg:px-12 py-10 grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-12">
        {/* Left — form */}
        <div>
          <Link href="/shop" className="inline-flex items-center gap-2 font-mono text-xs text-noise-text hover:text-lime mb-8 transition-colors">
            <ArrowLeft size={12}/> CONTINUE SHOPPING
          </Link>

          {step === "information" && (
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-3xl text-noise-white mb-1">CONTACT</h2>
                <input type="email" placeholder="EMAIL ADDRESS" value={form.email}
                  onChange={e=>setForm(f=>({...f,email:e.target.value}))}
                  className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest mt-3"/>
              </div>
              <div>
                <h2 className="font-display text-3xl text-noise-white mb-3">DELIVERY</h2>
                <div className="grid grid-cols-2 gap-3">
                  <input placeholder="FIRST NAME" value={form.firstName} onChange={e=>setForm(f=>({...f,firstName:e.target.value}))} className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
                  <input placeholder="LAST NAME"  value={form.lastName}  onChange={e=>setForm(f=>({...f,lastName:e.target.value}))}  className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
                  <input placeholder="ADDRESS"    value={form.address}   onChange={e=>setForm(f=>({...f,address:e.target.value}))}   className="shoutout-input col-span-2 px-4 py-3 text-sm font-mono tracking-widest"/>
                  <input placeholder="CITY"       value={form.city}      onChange={e=>setForm(f=>({...f,city:e.target.value}))}      className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
                  <input placeholder="ZIP CODE"   value={form.zip}       onChange={e=>setForm(f=>({...f,zip:e.target.value}))}       className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
                  <input placeholder="PHONE"      value={form.phone}     onChange={e=>setForm(f=>({...f,phone:e.target.value}))}     className="shoutout-input col-span-2 px-4 py-3 text-sm font-mono tracking-widest"/>
                </div>
              </div>
              <button onClick={()=>setStep("shipping")} className="btn-lime w-full py-4 text-lg flex items-center justify-center gap-2">
                CONTINUE TO SHIPPING <ChevronRight size={16}/>
              </button>
            </div>
          )}

          {step === "shipping" && (
            <div className="space-y-6">
              <h2 className="font-display text-3xl text-noise-white">SHIPPING METHOD</h2>
              <div className="space-y-3">
                {[
                  { id:"standard", label:"STANDARD SHIPPING", days:"3-5 business days", price: total>1500?0:50 },
                  { id:"express",  label:"EXPRESS SHIPPING",  days:"1-2 business days", price:150 },
                ].map(opt=>(
                  <button key={opt.id} onClick={()=>setShipping(opt.id)}
                    className={`w-full flex items-center justify-between p-4 border transition-all ${shipping===opt.id?"border-lime bg-lime/5":"border-noise-border hover:border-noise-muted"}`}>
                    <div className="flex items-center gap-3">
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${shipping===opt.id?"border-lime":"border-noise-border"}`}>
                        {shipping===opt.id&&<div className="w-2 h-2 rounded-full bg-lime"/>}
                      </div>
                      <div className="text-left">
                        <p className="font-mono text-xs text-noise-white tracking-wider">{opt.label}</p>
                        <p className="font-mono text-xs text-noise-text mt-0.5">{opt.days}</p>
                      </div>
                    </div>
                    <span className="font-mono text-sm text-lime">{opt.price===0?"FREE":formatPrice(opt.price)}</span>
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <button onClick={()=>setStep("information")} className="btn-outline px-6 py-4 text-sm flex items-center gap-2"><ArrowLeft size={14}/>BACK</button>
                <button onClick={()=>setStep("payment")} className="btn-lime flex-1 py-4 text-lg flex items-center justify-center gap-2">CONTINUE TO PAYMENT<ChevronRight size={16}/></button>
              </div>
            </div>
          )}

          {step === "payment" && (
            <div className="space-y-6">
              <h2 className="font-display text-3xl text-noise-white">PAYMENT</h2>
              <div className="border border-lime/20 bg-lime/5 p-4 flex items-center gap-3">
                <Lock size={14} className="text-lime flex-shrink-0"/>
                <p className="font-mono text-xs text-noise-text">Transactions are secured with 256-bit encryption. Powered by Stripe.</p>
              </div>
              <div className="space-y-3">
                <input placeholder="CARD NUMBER" className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
                <div className="grid grid-cols-2 gap-3">
                  <input placeholder="MM / YY" className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
                  <input placeholder="CVC" className="shoutout-input px-4 py-3 text-sm font-mono tracking-widest"/>
                </div>
                <input placeholder="NAME ON CARD" className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
              </div>
              <div className="flex gap-3">
                <button onClick={()=>setStep("shipping")} className="btn-outline px-6 py-4 text-sm flex items-center gap-2"><ArrowLeft size={14}/>BACK</button>
                <button onClick={handlePlaceOrder} className="btn-lime flex-1 py-4 text-lg flex items-center justify-center gap-2">
                  <Lock size={16}/> PAY {formatPrice(finalTotal)}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right — order summary */}
        <div className="border border-noise-border bg-noise-card p-6 h-fit sticky top-24 space-y-4">
          <h3 className="font-display text-2xl text-noise-white">ORDER SUMMARY</h3>
          <div className="space-y-3 border-b border-noise-border pb-4">
            {items.map(item=>(
              <div key={`${item.productId}-${item.size}`} className="flex items-center gap-3">
                <div className="w-14 h-16 bg-noise-dark border border-noise-border flex items-center justify-center flex-shrink-0 relative">
                  <span className="font-display text-lg text-noise-border/50">SO</span>
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-lime text-noise-black text-[9px] font-mono font-bold rounded-full flex items-center justify-center">{item.quantity}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display text-xs tracking-wider text-noise-white truncate">{item.name}</p>
                  <p className="font-mono text-[10px] text-noise-text">SIZE: {item.size}</p>
                </div>
                <span className="font-mono text-xs text-lime">{formatPrice(item.price*item.quantity)}</span>
              </div>
            ))}
          </div>

          {/* Discount */}
          <div className="flex gap-2">
            <input value={discount} onChange={e=>setDiscount(e.target.value)} placeholder="DISCOUNT CODE" className="shoutout-input flex-1 px-3 py-2 text-xs font-mono tracking-widest"/>
            <button onClick={applyDiscount} className="btn-outline px-4 py-2 text-xs">APPLY</button>
          </div>

          {/* Totals */}
          <div className="space-y-2 border-t border-noise-border pt-4">
            <div className="flex justify-between font-mono text-xs text-noise-text">
              <span>SUBTOTAL</span><span>{formatPrice(total)}</span>
            </div>
            <div className="flex justify-between font-mono text-xs text-noise-text">
              <span>SHIPPING</span><span>{shippingCost===0?"FREE":formatPrice(shippingCost)}</span>
            </div>
            {discountApplied&&(
              <div className="flex justify-between font-mono text-xs text-lime">
                <span>DISCOUNT (NOISE10)</span><span>-{formatPrice(discountAmount)}</span>
              </div>
            )}
            <div className="flex justify-between font-display text-xl text-noise-white border-t border-noise-border pt-3">
              <span>TOTAL</span><span className="text-lime">{formatPrice(finalTotal)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
