"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { Zap, Lock, ChevronRight } from "lucide-react";
import { MOCK_DROPS, MOCK_PRODUCTS, formatPrice } from "@/lib/utils";

function Countdown({ target }: { target: Date }) {
  const [t, setT] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  useEffect(() => {
    const tick = () => {
      const diff = Math.max(0, target.getTime() - Date.now());
      setT({ days: Math.floor(diff/86400000), hours: Math.floor((diff%86400000)/3600000), minutes: Math.floor((diff%3600000)/60000), seconds: Math.floor((diff%60000)/1000) });
    };
    tick(); const id = setInterval(tick, 1000); return () => clearInterval(id);
  }, [target]);
  const pad = (n: number) => String(n).padStart(2,"0");
  return (
    <div className="flex gap-4 font-display text-4xl">
      {[{v:t.days,l:"D"},{v:t.hours,l:"H"},{v:t.minutes,l:"M"},{v:t.seconds,l:"S"}].map(({v,l},i)=>(
        <div key={l} className="flex items-baseline gap-1">
          <span className="text-lime tabular-nums">{pad(v)}</span>
          <span className="text-noise-text text-xs font-mono">{l}</span>
          {i<3&&<span className="text-noise-border ml-3">:</span>}
        </div>
      ))}
    </div>
  );
}

export default function DropsPage() {
  const drop = MOCK_DROPS[0];
  const dropProducts = MOCK_PRODUCTS.filter(p => p.dropId === drop.id);

  return (
    <div className="min-h-screen pt-20">
      {/* Hero */}
      <div className="relative border-b border-noise-border overflow-hidden">
        <div className="absolute inset-0 bg-grid-noise bg-grid opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-noise-black" />
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 py-20 lg:py-32">
          <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between gap-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-2 h-2 bg-lime rounded-full animate-pulse" />
                <span className="font-mono text-xs text-lime tracking-ultrawide">UPCOMING DROP</span>
              </div>
              <h1 className="font-display text-[clamp(3rem,10vw,8rem)] text-noise-white leading-none mb-4">
                {drop.name.split("—")[0]}
                <span className="block text-lime">THE FIRST NOISE</span>
              </h1>
              <p className="font-body text-noise-text max-w-md leading-relaxed">
                {drop.description}
              </p>
            </div>
            <div className="border border-lime/20 p-6 bg-noise-black/60 backdrop-blur-sm min-w-[280px]">
              <p className="font-mono text-xs text-noise-text tracking-ultrawide mb-3">DROPS IN</p>
              <Countdown target={drop.dropDate} />
              <div className="mt-4 pt-4 border-t border-noise-border">
                <Link href="/drops/drop-001" className="btn-lime w-full py-3 text-base flex items-center justify-center gap-2">
                  <Zap size={15}/> VIEW DROP
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Drop products preview */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">DROPPING SOON</p>
            <h2 className="font-display text-5xl text-noise-white">PIECES</h2>
          </div>
          <span className="font-mono text-xs text-noise-text">{dropProducts.length} ITEMS</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {dropProducts.map(product => (
            <Link key={product.id} href={`/shop/${product.slug}`} className="product-card group border border-noise-border hover:border-lime/30 transition-all bg-noise-card relative">
              <div className="aspect-[3/4] overflow-hidden flex items-center justify-center bg-noise-dark relative">
                <span className="font-display text-6xl text-noise-border/40 group-hover:text-noise-muted transition-colors">SO</span>
                <div className="absolute inset-0 bg-noise-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex items-center gap-2 font-mono text-xs text-lime">
                    VIEW PIECE <ChevronRight size={12}/>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <p className="font-display text-sm tracking-wider text-noise-white group-hover:text-lime transition-colors leading-tight">{product.name}</p>
                <p className="font-mono text-xs text-noise-text mt-1">{product.category}</p>
                <p className="font-mono text-sm text-lime mt-2">{formatPrice(product.price)}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Past drops archive */}
      <div className="border-t border-noise-border px-6 lg:px-12 py-16">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="font-mono text-xs text-noise-text tracking-ultrawide mb-2">HISTORY</p>
              <h2 className="font-display text-5xl text-noise-white">PAST DROPS</h2>
            </div>
            <Link href="/archive" className="btn-outline px-4 py-2 text-xs flex items-center gap-2">
              ARCHIVE <ChevronRight size={12}/>
            </Link>
          </div>
          <div className="flex items-center justify-center border border-dashed border-noise-border py-16">
            <div className="text-center">
              <Lock size={32} className="text-noise-muted mx-auto mb-4"/>
              <p className="font-display text-2xl text-noise-border">NO PAST DROPS</p>
              <p className="font-mono text-xs text-noise-text mt-2">DROP 001 IS THE BEGINNING</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
