"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import toast from "react-hot-toast";

export default function SignUpPage() {
  const [form, setForm] = useState({ firstName:"", lastName:"", email:"", password:"" });
  const [earlyAccess, setEarlyAccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Account created. Welcome to the noise.");
    setTimeout(() => window.location.href = "/account", 1000);
  };

  return (
    <div className="min-h-screen bg-noise-black flex">
      {/* Left */}
      <div className="hidden lg:flex lg:w-1/2 bg-lime flex-col justify-between p-16 relative overflow-hidden">
        <div className="absolute inset-0" style={{backgroundImage:"linear-gradient(rgba(0,0,0,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.05) 1px, transparent 1px)", backgroundSize:"40px 40px"}}/>
        <div className="relative">
          <Link href="/" className="flex items-baseline gap-1">
            <span className="font-display text-3xl text-noise-black">SHOUTOUT</span>
            <span className="text-noise-black text-sm font-mono opacity-50">™</span>
          </Link>
        </div>
        <div className="relative">
          <p className="font-mono text-xs text-noise-black/50 tracking-ultrawide mb-4">JOIN THE SCENE</p>
          <h2 className="font-display text-7xl text-noise-black leading-none mb-6">
            THE<br/>NOISE<br/>NEEDS<br/>YOU.
          </h2>
          <p className="font-body text-noise-black/70 text-sm leading-relaxed max-w-xs">
            Create an account for early access to drops, exclusive content, and the inner circle.
          </p>
        </div>
        <p className="relative font-mono text-xs text-noise-black/40">© 2026 SHOUTOUT™</p>
      </div>

      {/* Right */}
      <div className="w-full lg:w-1/2 flex items-center justify-center px-6 py-20">
        <div className="w-full max-w-md space-y-8">
          <div className="lg:hidden">
            <Link href="/" className="flex items-baseline gap-1">
              <span className="font-display text-2xl text-noise-white">SHOUTOUT</span>
              <span className="text-lime text-xs font-mono">™</span>
            </Link>
          </div>

          <div>
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">NEW MEMBER</p>
            <h1 className="font-display text-5xl text-noise-white">CREATE ACCOUNT</h1>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">FIRST NAME</label>
                <input value={form.firstName} onChange={e=>setForm(f=>({...f,firstName:e.target.value}))} required
                  placeholder="Yusuf" className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
              </div>
              <div>
                <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">LAST NAME</label>
                <input value={form.lastName} onChange={e=>setForm(f=>({...f,lastName:e.target.value}))} required
                  placeholder="G." className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
              </div>
            </div>
            <div>
              <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">EMAIL</label>
              <input type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} required
                placeholder="your@email.com" className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
            </div>
            <div>
              <label className="font-mono text-[10px] text-noise-text tracking-ultrawide block mb-2">PASSWORD</label>
              <input type="password" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))} required
                placeholder="Min. 8 characters" className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"/>
            </div>

            <label className="flex items-start gap-3 cursor-pointer group">
              <input type="checkbox" checked={earlyAccess} onChange={e=>setEarlyAccess(e.target.checked)} className="accent-lime mt-0.5"/>
              <span className="font-mono text-xs text-noise-text group-hover:text-noise-light transition-colors leading-relaxed">
                ADD ME TO THE EARLY ACCESS WHITELIST FOR DROP 001
              </span>
            </label>

            <button type="submit" className="btn-lime w-full py-4 text-lg flex items-center justify-center gap-2">
              JOIN THE NOISE <ArrowRight size={16}/>
            </button>

            <p className="font-mono text-[10px] text-noise-border text-center leading-relaxed">
              By creating an account you agree to our Terms of Service and Privacy Policy.
            </p>
          </form>

          <div className="border-t border-noise-border pt-6 flex items-center justify-between">
            <p className="font-mono text-xs text-noise-text">ALREADY A MEMBER?</p>
            <Link href="/sign-in" className="font-mono text-xs text-lime hover:text-noise-white transition-colors flex items-center gap-1">
              SIGN IN <ArrowRight size={11}/>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
