"use client";
import { useEffect, useRef, useState } from "react";
import { ArrowDown } from "lucide-react";

const INTRO_WORDS = ["THE", "NOISE", "IS", "COMING"];

export default function Hero() {
  const [phase, setPhase] = useState<"intro" | "hero">("intro");
  const [wordIndex, setWordIndex] = useState(-1);
  const [showHero, setShowHero] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Sequence the intro words
    let i = 0;
    const interval = setInterval(() => {
      setWordIndex(i);
      i++;
      if (i >= INTRO_WORDS.length) {
        clearInterval(interval);
        setTimeout(() => {
          setPhase("hero");
          setShowHero(true);
        }, 800);
      }
    }, 400);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative w-full h-screen overflow-hidden">
      {/* Intro overlay */}
      <div
        className={`absolute inset-0 z-20 bg-noise-black flex items-center justify-center transition-all duration-700 ease-in-out ${
          phase === "hero" ? "opacity-0 pointer-events-none" : "opacity-100"
        }`}
      >
        <div className="text-center space-y-4">
          {INTRO_WORDS.map((word, idx) => (
            <div
              key={word}
              className={`font-display text-[clamp(3rem,12vw,9rem)] leading-none transition-all duration-300 ${
                idx <= wordIndex ? "opacity-100 text-noise-white" : "opacity-0"
              } ${idx === wordIndex ? "text-lime lime-text-glow" : ""}`}
            >
              {word}
            </div>
          ))}
        </div>
      </div>

      {/* Hero background */}
      <div
        className={`absolute inset-0 transition-opacity duration-1000 ${showHero ? "opacity-100" : "opacity-0"}`}
      >
        {/* Dark gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-noise-black/60 via-transparent to-noise-black z-10" />
        <div className="absolute inset-0 bg-gradient-to-r from-noise-black/50 to-transparent z-10" />

        {/* Background image — campaign style */}
        <div className="w-full h-full bg-noise-dark flex items-center justify-center overflow-hidden">
          {/* Brutalist grid bg */}
          <div className="absolute inset-0 bg-grid-noise bg-grid opacity-50" />
          {/* Campaign visual */}
          <div className="w-full h-full relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-[600px] h-[600px] border border-noise-border/30 rotate-12 opacity-20" />
              <div className="w-[400px] h-[400px] border border-lime/10 -rotate-6 opacity-30 absolute" />
            </div>
          </div>
        </div>
      </div>

      {/* Hero content */}
      <div
        className={`relative z-20 h-full flex flex-col justify-end pb-16 px-6 lg:px-12 transition-all duration-1000 delay-300 ${
          showHero ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="max-w-7xl mx-auto w-full">
          <div className="flex flex-col lg:flex-row items-end justify-between gap-8">
            <div>
              <p className="font-mono text-xs text-lime tracking-ultrawide mb-4 animate-fadeUp">
                DROP 001 — THE FIRST NOISE
              </p>
              <h1 className="font-display text-[clamp(4rem,14vw,10rem)] text-noise-white leading-none">
                <span className="block glitch-text" data-text="SHOUT">SHOUT</span>
                <span className="block text-lime lime-text-glow glitch-text" data-text="OUT">OUT</span>
              </h1>
              <p className="font-mono text-sm text-noise-light mt-4 max-w-xs">
                Culture-first streetwear. Underground energy.<br/>
                10 pieces. No restock.
              </p>
            </div>

            <div className="flex flex-col items-start lg:items-end gap-4">
              <div className="border border-lime/30 px-6 py-4 bg-noise-black/50 backdrop-blur-sm">
                <p className="font-mono text-xs text-noise-text mb-1 tracking-ultrawide">DROP IN</p>
                <CountdownDisplay />
              </div>
              <a
                href="#drop"
                className="btn-lime px-8 py-4 text-xl font-display tracking-wider flex items-center gap-3 hover:gap-5 transition-all"
              >
                SEE THE DROP <ArrowDown size={18} />
              </a>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40">
          <div className="w-px h-8 bg-noise-text animate-bounce" />
          <span className="font-mono text-xs text-noise-text tracking-ultrawide">SCROLL</span>
        </div>
      </div>
    </section>
  );
}

function CountdownDisplay() {
  const [time, setTime] = useState({ days: 3, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const target = new Date(Date.now() + 1000 * 60 * 60 * 24 * 3);
    const tick = () => {
      const now = Date.now();
      const diff = Math.max(0, target.getTime() - now);
      setTime({
        days: Math.floor(diff / 86400000),
        hours: Math.floor((diff % 86400000) / 3600000),
        minutes: Math.floor((diff % 3600000) / 60000),
        seconds: Math.floor((diff % 60000) / 1000),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <div className="flex items-center gap-4 font-display text-3xl text-noise-white">
      {[
        { v: time.days, l: "D" },
        { v: time.hours, l: "H" },
        { v: time.minutes, l: "M" },
        { v: time.seconds, l: "S" },
      ].map(({ v, l }, i) => (
        <div key={l} className="flex items-baseline gap-1">
          <span className="text-lime tabular-nums">{pad(v)}</span>
          <span className="text-noise-text text-xs font-mono">{l}</span>
          {i < 3 && <span className="text-noise-muted ml-3">:</span>}
        </div>
      ))}
    </div>
  );
}
