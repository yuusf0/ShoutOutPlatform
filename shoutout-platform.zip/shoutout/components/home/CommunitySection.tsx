"use client";
import { useState } from "react";
import { MessageSquare, ArrowRight, Users, Zap } from "lucide-react";
import toast from "react-hot-toast";

export default function CommunitySection() {
  const [email, setEmail] = useState("");

  const handleEarlyAccess = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    toast.success("You're on the early access list.");
    setEmail("");
  };

  return (
    <section className="bg-noise-dark border-y border-noise-border py-20 overflow-hidden relative">
      {/* Background big text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden select-none">
        <span className="font-display text-[20vw] text-noise-border/10 whitespace-nowrap">COMMUNITY</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left — Discord */}
          <div>
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">THE INNER CIRCLE</p>
            <h2 className="font-display text-[clamp(3rem,6vw,5rem)] text-noise-white leading-none mb-6">
              JOIN THE<br/>DISCORD
            </h2>
            <p className="font-body text-noise-text text-sm leading-relaxed mb-8 max-w-sm">
              First access to drops. Behind-the-scenes content. Direct line to the team. 
              The culture lives here.
            </p>

            <div className="flex flex-col gap-3 mb-8">
              {[
                { icon: Zap, label: "EARLY DROP ACCESS", desc: "Get links before they go public" },
                { icon: Users, label: "COMMUNITY MEMBERS", desc: "500+ people in the scene" },
                { icon: MessageSquare, label: "DIRECT CHAT", desc: "Talk to the ShoutOut team" },
              ].map(({ icon: Icon, label, desc }) => (
                <div key={label} className="flex items-start gap-4 p-4 border border-noise-border bg-noise-black/50">
                  <Icon size={16} className="text-lime mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-mono text-xs text-noise-white tracking-wider">{label}</p>
                    <p className="font-mono text-xs text-noise-text mt-0.5">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <a
              href="https://discord.gg/shoutout"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-lime inline-flex items-center gap-3 px-8 py-4 text-lg"
            >
              <MessageSquare size={18} /> JOIN DISCORD
            </a>
          </div>

          {/* Right — Early access whitelist */}
          <div className="border border-noise-border bg-noise-black/60 p-8">
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">EXCLUSIVE</p>
            <h3 className="font-display text-3xl text-noise-white mb-2">EARLY ACCESS<br/>WHITELIST</h3>
            <p className="font-body text-noise-text text-sm mb-6 leading-relaxed">
              Drop 001 drops to whitelist members 24h before public.
              500 spots. No waitlist after.
            </p>

            <form onSubmit={handleEarlyAccess} className="space-y-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="YOUR EMAIL"
                className="shoutout-input w-full px-4 py-3 text-sm font-mono tracking-widest"
              />
              <button type="submit" className="btn-lime w-full py-4 text-lg flex items-center justify-center gap-2">
                SECURE MY SPOT <ArrowRight size={16} />
              </button>
            </form>

            <div className="mt-6 pt-6 border-t border-noise-border flex items-center justify-between">
              <div className="text-center">
                <p className="font-display text-3xl text-lime">423</p>
                <p className="font-mono text-xs text-noise-text mt-1">SPOTS TAKEN</p>
              </div>
              <div className="text-center">
                <p className="font-display text-3xl text-noise-white">77</p>
                <p className="font-mono text-xs text-noise-text mt-1">REMAINING</p>
              </div>
              <div className="text-center">
                <p className="font-display text-3xl text-lime">24H</p>
                <p className="font-mono text-xs text-noise-text mt-1">EARLY ACCESS</p>
              </div>
            </div>

            {/* Progress bar */}
            <div className="mt-4">
              <div className="h-px bg-noise-border w-full relative overflow-hidden">
                <div className="absolute left-0 top-0 h-full bg-lime" style={{ width: "84.6%" }} />
              </div>
              <p className="font-mono text-[10px] text-noise-text mt-1 text-right">84.6% FULL</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
