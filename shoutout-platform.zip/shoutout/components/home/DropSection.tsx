"use client";
import Link from "next/link";
import { ArrowRight, Zap } from "lucide-react";
import { MOCK_PRODUCTS, formatPrice, RARITY_CONFIG } from "@/lib/utils";
import { useCartStore } from "@/store/cart";
import toast from "react-hot-toast";

export default function DropSection() {
  const { addItem } = useCartStore();

  const handleQuickAdd = (product: typeof MOCK_PRODUCTS[0]) => {
    addItem({
      id: `${product.id}-M`,
      productId: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      size: "M",
      slug: product.slug,
    });
    toast.success(`${product.name} — size M added`);
  };

  return (
    <section id="drop" className="px-6 lg:px-12 py-20 max-w-7xl mx-auto">
      {/* Section header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between mb-12 gap-4">
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-3">NOW AVAILABLE</p>
          <h2 className="font-display text-[clamp(3rem,8vw,6rem)] text-noise-white leading-none">
            DROP 001
          </h2>
          <p className="font-mono text-sm text-noise-text mt-2">THE FIRST NOISE — 10 PIECES ONLY</p>
        </div>
        <Link href="/drops/drop-001" className="btn-outline px-6 py-3 text-sm flex items-center gap-2">
          VIEW ALL <ArrowRight size={14} />
        </Link>
      </div>

      {/* Product grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {MOCK_PRODUCTS.map((product, idx) => {
          const rarity = RARITY_CONFIG[product.rarity as keyof typeof RARITY_CONFIG];
          return (
            <div
              key={product.id}
              className="product-card group relative bg-noise-card border border-noise-border hover:border-lime/30 transition-all duration-300"
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              {/* Product image */}
              <Link href={`/shop/${product.slug}`}>
                <div className="relative overflow-hidden aspect-[3/4] bg-noise-dark">
                  <div className="product-image w-full h-full transition-transform duration-500 flex items-center justify-center">
                    <span className="font-display text-7xl text-noise-border group-hover:text-noise-muted transition-colors">SO</span>
                  </div>

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-1">
                    {product.isLimited && (
                      <span className="bg-lime text-noise-black text-[9px] font-mono font-bold px-2 py-0.5 tracking-widest">
                        LIMITED
                      </span>
                    )}
                    <span className={`text-[9px] font-mono px-2 py-0.5 tracking-widest ${rarity?.class}`}>
                      {rarity?.label}
                    </span>
                  </div>

                  {/* Stock indicator */}
                  <div className="absolute top-3 right-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-lime animate-pulse" />
                      <span className="font-mono text-[9px] text-noise-text">IN STOCK</span>
                    </div>
                  </div>

                  {/* Quick add overlay */}
                  <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button
                      onClick={() => handleQuickAdd(product)}
                      className="btn-lime w-full py-3 text-sm flex items-center justify-center gap-2"
                    >
                      <Zap size={14} /> QUICK ADD — M
                    </button>
                  </div>
                </div>
              </Link>

              {/* Info */}
              <div className="p-4">
                <Link href={`/shop/${product.slug}`}>
                  <p className="font-display text-base tracking-wider text-noise-white hover:text-lime transition-colors leading-tight mb-1">
                    {product.name}
                  </p>
                </Link>
                <p className="font-mono text-xs text-noise-text mb-3">{product.category}</p>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm text-lime">{formatPrice(product.price)}</span>
                  {product.comparePrice && (
                    <span className="font-mono text-xs text-noise-muted line-through">{formatPrice(product.comparePrice)}</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
