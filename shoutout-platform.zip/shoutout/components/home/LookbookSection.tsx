"use client";
import { useState } from "react";
import { ArrowRight, ArrowLeft } from "lucide-react";

const LOOKBOOK_ITEMS = [
  { id: 1, label: "LOOK 01", title: "THE SIGNAL", subtitle: "Black Logo Tee + Cargo" },
  { id: 2, label: "LOOK 02", title: "THE MOVE",  subtitle: "White Logo Tee + Shorts" },
  { id: 3, label: "LOOK 03", title: "THE NOISE", subtitle: "Noise Hoodie + Track" },
];

export default function LookbookSection() {
  const [active, setActive] = useState(0);

  return (
    <section className="py-20 px-6 lg:px-12 max-w-7xl mx-auto">
      <div className="flex items-end justify-between mb-12">
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-3">EDITORIAL</p>
          <h2 className="font-display text-[clamp(2.5rem,6vw,5rem)] text-noise-white leading-none">
            LOOKBOOK
          </h2>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setActive((a) => Math.max(0, a - 1))}
            disabled={active === 0}
            className="w-10 h-10 border border-noise-border flex items-center justify-center text-noise-text hover:border-lime hover:text-lime transition-all disabled:opacity-30"
          >
            <ArrowLeft size={16} />
          </button>
          <button
            onClick={() => setActive((a) => Math.min(LOOKBOOK_ITEMS.length - 1, a + 1))}
            disabled={active === LOOKBOOK_ITEMS.length - 1}
            className="w-10 h-10 border border-noise-border flex items-center justify-center text-noise-text hover:border-lime hover:text-lime transition-all disabled:opacity-30"
          >
            <ArrowRight size={16} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {LOOKBOOK_ITEMS.map((item, idx) => (
          <div
            key={item.id}
            className={`relative overflow-hidden cursor-pointer transition-all duration-500 ${
              idx === active ? "lg:col-span-2 aspect-[4/5]" : "aspect-square lg:aspect-[3/4]"
            }`}
            onClick={() => setActive(idx)}
          >
            {/* Placeholder image */}
            <div className="w-full h-full bg-noise-card border border-noise-border flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-grid-noise bg-grid opacity-20" />
              <div className="text-center relative z-10">
                <span className="font-display text-[8rem] text-noise-border/30 leading-none">SO</span>
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-noise-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 p-6">
                <p className="font-mono text-xs text-lime tracking-ultrawide mb-1">{item.label}</p>
                <h4 className="font-display text-3xl text-noise-white">{item.title}</h4>
                <p className="font-mono text-xs text-noise-text mt-1">{item.subtitle}</p>
              </div>
              {/* Active indicator */}
              {idx === active && (
                <div className="absolute top-4 right-4 w-2 h-2 bg-lime rounded-full" />
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
