export default function MarqueeTicker({ items = ["THE NOISE IS COMING", "DROP 001", "NO RESTOCK", "CULTURE FIRST", "SHOUTOUT™", "UNDERGROUND", "PREMIUM"] }) {
  const doubled = [...items, ...items];
  return (
    <div className="bg-noise-card border-y border-noise-border overflow-hidden py-3">
      <div className="marquee-inner flex gap-10">
        {doubled.map((item, i) => (
          <span key={i} className="font-display text-lg text-noise-white whitespace-nowrap flex items-center gap-10">
            {item}
            <span className="text-lime">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
