"use client";
import { useEffect, useRef } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function CampaignSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("revealed");
          }
        });
      },
      { threshold: 0.1 }
    );
    const elements = sectionRef.current?.querySelectorAll(".reveal");
    elements?.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="overflow-hidden">
      {/* Full-width campaign banner */}
      <div className="relative h-[70vh] bg-noise-dark flex items-center justify-center overflow-hidden border-y border-noise-border">
        {/* Background grid */}
        <div className="absolute inset-0 bg-grid-noise bg-grid opacity-30" />

        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-px h-full bg-gradient-to-b from-transparent via-lime/20 to-transparent" />
        <div className="absolute top-0 right-0 w-px h-full bg-gradient-to-b from-transparent via-lime/20 to-transparent" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-lime/20 to-transparent" />

        {/* Huge background text */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
          <span className="font-display text-[25vw] text-noise-border/20 whitespace-nowrap leading-none">
            NOISE
          </span>
        </div>

        {/* Content */}
        <div className="relative z-10 text-center px-6">
          <p className="reveal font-mono text-xs text-lime tracking-ultrawide mb-6">BURSA, TURKEY — 2026</p>
          <h2 className="reveal font-display text-[clamp(3rem,10vw,8rem)] text-noise-white leading-none mb-6">
            IDENTITY<br/>
            <span className="text-lime">FIRST</span>
          </h2>
          <p className="reveal font-body text-noise-text max-w-md mx-auto text-sm leading-relaxed mb-8">
            We don't sell clothes. We sell a position.<br/>
            Underground by design. Premium by execution.
          </p>
          <Link href="/culture" className="reveal btn-outline px-8 py-4 text-sm inline-flex items-center gap-3">
            THE STORY <ArrowRight size={14} />
          </Link>
        </div>
      </div>

      {/* 2-column editorial */}
      <div className="grid grid-cols-1 lg:grid-cols-2 border-b border-noise-border">
        {/* Left — dark */}
        <div className="relative bg-noise-black p-12 lg:p-20 flex flex-col justify-end min-h-[500px] border-r border-noise-border overflow-hidden">
          <div className="absolute inset-0 bg-grid-noise bg-grid opacity-20" />
          <div className="absolute top-12 right-12 font-display text-8xl text-noise-border/30 leading-none">01</div>
          <div className="relative">
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">THE CULTURE</p>
            <h3 className="font-display text-5xl text-noise-white leading-none mb-4">
              UNDERGROUND<br/>ENERGY
            </h3>
            <p className="font-body text-noise-text text-sm leading-relaxed max-w-xs">
              Rooted in Turkish street and rap culture. Worn by those who move the scene, not follow it.
            </p>
          </div>
        </div>

        {/* Right — lime */}
        <div className="relative bg-lime p-12 lg:p-20 flex flex-col justify-end min-h-[500px] overflow-hidden">
          <div className="absolute top-12 right-12 font-display text-8xl text-noise-black/10 leading-none">02</div>
          <div className="relative">
            <p className="font-mono text-xs text-noise-black/50 tracking-ultrawide mb-4">THE EXECUTION</p>
            <h3 className="font-display text-5xl text-noise-black leading-none mb-4">
              PREMIUM<br/>ALWAYS
            </h3>
            <p className="font-body text-noise-black/70 text-sm leading-relaxed max-w-xs">
              280gsm cotton. Screen-printed graphics. Quality that lasts longer than the hype.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
