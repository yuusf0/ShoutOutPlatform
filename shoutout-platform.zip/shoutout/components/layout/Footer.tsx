"use client";
import Link from "next/link";
import { useState } from "react";
import { ArrowRight, Globe, Share2, Music } from "lucide-react";
import toast from "react-hot-toast";

export default function Footer() {
  const [email, setEmail] = useState("");

  const handleNewsletter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    toast.success("You're on the list.");
    setEmail("");
  };

  return (
    <footer className="bg-noise-dark border-t border-noise-border mt-0">
      {/* Newsletter strip */}
      <div className="border-b border-noise-border px-6 py-12 lg:py-16">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-8">
          <div>
            <p className="font-mono text-xs text-lime tracking-ultrawide mb-2">BE FIRST</p>
            <h3 className="font-display text-4xl lg:text-5xl text-noise-white">
              JOIN THE NOISE
            </h3>
          </div>
          <form onSubmit={handleNewsletter} className="flex w-full lg:w-auto lg:min-w-[420px]">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="YOUR EMAIL"
              className="shoutout-input flex-1 px-4 py-3 text-sm font-mono tracking-widest"
            />
            <button type="submit" className="btn-lime px-6 py-3 text-lg flex items-center gap-2 whitespace-nowrap">
              SIGN UP <ArrowRight size={16} />
            </button>
          </form>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12 grid grid-cols-2 lg:grid-cols-5 gap-8">
        {/* Brand */}
        <div className="col-span-2">
          <div className="flex items-baseline gap-1 mb-4">
            <span className="font-display text-3xl text-noise-white">SHOUTOUT</span>
            <span className="text-lime text-xs font-mono">™</span>
          </div>
          <p className="text-noise-text text-sm font-body leading-relaxed max-w-xs mb-6">
            Culture-first streetwear from Bursa. Underground energy, premium execution. 
            Limited drops. No restock. Ever.
          </p>
          <div className="flex gap-4">
            {[Globe, Share2, Music].map((Icon, i) => (
              <a key={i} href="#" className="text-noise-text hover:text-lime transition-colors">
                <Icon size={18} />
              </a>
            ))}
          </div>
        </div>

        {/* Shop */}
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">SHOP</p>
          {["Tees", "Hoodies", "Accessories", "All Products"].map((item) => (
            <Link key={item} href="/shop" className="block text-noise-text hover:text-noise-white text-sm mb-2 transition-colors">
              {item}
            </Link>
          ))}
        </div>

        {/* Info */}
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">INFO</p>
          {["About", "Sizing Guide", "Care Instructions", "Contact"].map((item) => (
            <a key={item} href="#" className="block text-noise-text hover:text-noise-white text-sm mb-2 transition-colors">
              {item}
            </a>
          ))}
        </div>

        {/* Legal */}
        <div>
          <p className="font-mono text-xs text-lime tracking-ultrawide mb-4">LEGAL</p>
          {["Privacy Policy", "Terms", "Shipping Policy", "Returns"].map((item) => (
            <a key={item} href="#" className="block text-noise-text hover:text-noise-white text-sm mb-2 transition-colors">
              {item}
            </a>
          ))}
          <div className="mt-6 pt-6 border-t border-noise-border">
            <a href="/admin" className="text-noise-muted hover:text-noise-text text-xs font-mono transition-colors">
              SHOUTOUT OS →
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-noise-border px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-2">
        <p className="text-noise-muted text-xs font-mono">© 2026 SHOUTOUT™. ALL RIGHTS RESERVED.</p>
        <p className="text-noise-muted text-xs font-mono">BURSA, TURKEY — DIGITAL-FIRST</p>
      </div>
    </footer>
  );
}
