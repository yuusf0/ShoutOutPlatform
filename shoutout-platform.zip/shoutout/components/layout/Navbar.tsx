"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { ShoppingBag, Menu, X, Search, User } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { label: "SHOP", href: "/shop" },
  { label: "DROPS", href: "/drops" },
  { label: "LOOKBOOK", href: "/lookbook" },
  { label: "ARCHIVE", href: "/archive" },
  { label: "CULTURE", href: "/culture" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { totalItems, toggleCart } = useCartStore();
  const count = totalItems();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
          scrolled ? "bg-noise-black/95 backdrop-blur-sm border-b border-noise-border" : "bg-transparent"
        )}
      >
        <div className="flex items-center justify-between px-6 h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <span className="font-display text-2xl text-noise-white tracking-wider group-hover:text-lime transition-colors">
              SHOUTOUT
            </span>
            <span className="text-lime text-xs font-mono">™</span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-noise-text hover:text-lime text-xs font-mono tracking-ultrawide transition-colors uppercase"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-4">
            <button className="text-noise-text hover:text-lime transition-colors p-1 hidden md:block">
              <Search size={18} />
            </button>
            <Link href="/account" className="text-noise-text hover:text-lime transition-colors p-1 hidden md:block">
              <User size={18} />
            </Link>
            <button
              onClick={toggleCart}
              className="text-noise-text hover:text-lime transition-colors p-1 relative"
            >
              <ShoppingBag size={18} />
              {count > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-lime text-noise-black text-[9px] font-mono font-bold rounded-full flex items-center justify-center">
                  {count}
                </span>
              )}
            </button>
            <button
              className="lg:hidden text-noise-text hover:text-lime transition-colors p-1"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Ticker tape */}
        {!scrolled && (
          <div className="bg-lime overflow-hidden h-7 flex items-center">
            <div className="marquee-inner text-noise-black font-mono text-xs font-bold">
              {Array(4).fill("THE NOISE IS COMING — DROP 001 — LIMITED PIECES — NO RESTOCK — SHOUTOUT™ — ").join("")}
            </div>
          </div>
        )}
      </header>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-noise-black flex flex-col pt-20 px-6">
          <nav className="flex flex-col gap-6 mt-10">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="font-display text-5xl text-noise-white hover:text-lime transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="mt-auto pb-10">
            <Link href="/account" className="flex items-center gap-2 text-noise-text hover:text-lime font-mono text-sm" onClick={() => setMenuOpen(false)}>
              <User size={16} /> ACCOUNT
            </Link>
          </div>
        </div>
      )}
    </>
  );
}
