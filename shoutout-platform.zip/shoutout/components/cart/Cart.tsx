"use client";
import { useCartStore } from "@/store/cart";
import { X, Plus, Minus, ShoppingBag, ArrowRight } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import Link from "next/link";
import { cn } from "@/lib/utils";

export default function Cart() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, totalPrice } = useCartStore();
  const total = totalPrice();

  return (
    <>
      {/* Backdrop */}
      <div
        className={cn(
          "fixed inset-0 z-[60] bg-noise-black/70 backdrop-blur-sm transition-opacity duration-300",
          isOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
        )}
        onClick={closeCart}
      />

      {/* Slide panel */}
      <div
        className={cn(
          "fixed right-0 top-0 h-full w-full max-w-md z-[70] bg-noise-dark border-l border-noise-border flex flex-col",
          "transition-transform duration-400 ease-[cubic-bezier(0.76,0,0.24,1)]",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-noise-border">
          <div className="flex items-center gap-3">
            <ShoppingBag size={18} className="text-lime" />
            <span className="font-display text-xl tracking-wider">CART</span>
            {items.length > 0 && (
              <span className="font-mono text-xs text-noise-text">({items.length})</span>
            )}
          </div>
          <button onClick={closeCart} className="text-noise-text hover:text-noise-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <ShoppingBag size={40} className="text-noise-muted" />
              <p className="font-mono text-xs text-noise-text tracking-ultrawide">YOUR BAG IS EMPTY</p>
              <Link
                href="/shop"
                onClick={closeCart}
                className="btn-lime px-6 py-3 text-sm flex items-center gap-2"
              >
                SHOP NOW <ArrowRight size={14} />
              </Link>
            </div>
          ) : (
            items.map((item) => (
              <div key={`${item.productId}-${item.size}`} className="flex gap-4 p-4 bg-noise-card border border-noise-border">
                <div className="w-20 h-24 bg-noise-muted flex-shrink-0 relative overflow-hidden">
                  <div className="w-full h-full bg-gradient-to-br from-noise-muted to-noise-border flex items-center justify-center">
                    <span className="font-display text-2xl text-noise-border">SO</span>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display text-sm tracking-wider truncate">{item.name}</p>
                  <p className="font-mono text-xs text-noise-text mt-1">SIZE: {item.size}</p>
                  <p className="text-lime font-mono text-sm mt-1">{formatPrice(item.price)}</p>
                  <div className="flex items-center gap-3 mt-3">
                    <button
                      onClick={() => updateQuantity(item.productId, item.size, item.quantity - 1)}
                      className="w-6 h-6 border border-noise-border flex items-center justify-center text-noise-text hover:border-lime hover:text-lime transition-colors"
                    >
                      <Minus size={12} />
                    </button>
                    <span className="font-mono text-sm w-4 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.productId, item.size, item.quantity + 1)}
                      className="w-6 h-6 border border-noise-border flex items-center justify-center text-noise-text hover:border-lime hover:text-lime transition-colors"
                    >
                      <Plus size={12} />
                    </button>
                    <button
                      onClick={() => removeItem(item.productId, item.size)}
                      className="ml-auto text-noise-muted hover:text-noise-white transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-noise-border px-6 py-6 space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-noise-text tracking-ultrawide">SUBTOTAL</span>
              <span className="font-display text-xl text-lime">{formatPrice(total)}</span>
            </div>
            <p className="text-noise-text text-xs font-mono">Shipping calculated at checkout</p>
            <Link
              href="/checkout"
              onClick={closeCart}
              className="btn-lime w-full py-4 text-lg font-display tracking-widest flex items-center justify-center gap-2"
            >
              CHECKOUT <ArrowRight size={16} />
            </Link>
            <button
              onClick={closeCart}
              className="btn-outline w-full py-3 text-sm font-display tracking-widest"
            >
              CONTINUE SHOPPING
            </button>
          </div>
        )}
      </div>
    </>
  );
}
