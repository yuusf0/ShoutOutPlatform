import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface CartItem {
  id: string;
  productId: string;
  name: string;
  price: number;
  image: string;
  size: string;
  color?: string;
  quantity: number;
  slug: string;
}

interface CartStore {
  items: CartItem[];
  isOpen: boolean;
  addItem: (item: Omit<CartItem, "quantity">) => void;
  removeItem: (productId: string, size: string) => void;
  updateQuantity: (productId: string, size: string, quantity: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
  openCart: () => void;
  closeCart: () => void;
  totalItems: () => number;
  totalPrice: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,

      addItem: (newItem) => {
        const items = get().items;
        const existing = items.find(
          (i) => i.productId === newItem.productId && i.size === newItem.size
        );
        if (existing) {
          set({ items: items.map((i) =>
            i.productId === newItem.productId && i.size === newItem.size
              ? { ...i, quantity: i.quantity + 1 }
              : i
          )});
        } else {
          set({ items: [...items, { ...newItem, quantity: 1 }] });
        }
        set({ isOpen: true });
      },

      removeItem: (productId, size) => {
        set({ items: get().items.filter(
          (i) => !(i.productId === productId && i.size === size)
        )});
      },

      updateQuantity: (productId, size, quantity) => {
        if (quantity <= 0) {
          get().removeItem(productId, size);
          return;
        }
        set({ items: get().items.map((i) =>
          i.productId === productId && i.size === size
            ? { ...i, quantity }
            : i
        )});
      },

      clearCart: () => set({ items: [] }),
      toggleCart: () => set({ isOpen: !get().isOpen }),
      openCart: () => set({ isOpen: true }),
      closeCart: () => set({ isOpen: false }),

      totalItems: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
      totalPrice: () => get().items.reduce((sum, i) => sum + i.price * i.quantity, 0),
    }),
    { name: "shoutout-cart" }
  )
);
